# Troubleshooting Guide

**Common issues and solutions for Trail Painter Duel**

This guide covers the most common problems you might encounter during development, deployment, or gameplay, along with step-by-step solutions.

## Table of Contents

- [Development Issues](#development-issues)
- [Database Problems](#database-problems)
- [Authentication Issues](#authentication-issues)
- [Real-time Problems](#real-time-problems)
- [Deployment Issues](#deployment-issues)
- [Game-specific Problems](#game-specific-problems)
- [Performance Issues](#performance-issues)
- [Browser Compatibility](#browser-compatibility)

## Development Issues

### Build Errors

#### "Cannot find module" errors

**Problem**: Import errors or missing dependencies

**Solution**:
```bash
# Clear node_modules and reinstall
rm -rf node_modules pnpm-lock.yaml
pnpm install

# Clear Vite cache
rm -rf .vite node_modules/.vite
pnpm dev
```

#### TypeScript compilation errors

**Problem**: Type errors preventing build

**Solution**:
1. Check `tsconfig.json` configuration
2. Ensure all types are properly imported
3. Update `@types/*` packages if needed

```bash
# Update TypeScript and types
pnpm update typescript @types/node @types/react @types/react-dom

# Check TypeScript errors
npx tsc --noEmit
```

#### Tailwind CSS not working

**Problem**: Styles not applying or not updating

**Solution**:
1. Verify `tailwind.config.js` includes all source files:
```javascript
/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  // ...
}
```

2. Check `postcss.config.js`:
```javascript
export default {
  plugins: {
    tailwindcss: {},
    autoprefixer: {},
  },
}
```

3. Restart development server after config changes

### Environment Variables

#### Environment variables not loading

**Problem**: `import.meta.env.VITE_*` returns undefined

**Solution**:
1. Ensure variables start with `VITE_`:
```env
# ✅ Correct
VITE_SUPABASE_URL=https://...

# ❌ Wrong
SUPABASE_URL=https://...
```

2. Check file naming:
- Development: `.env.local` or `.env`
- Production: Set in deployment platform

3. Restart development server after changes

## Database Problems

### Supabase Connection Issues

#### "Invalid API key" error

**Problem**: Authentication failing with Supabase

**Solution**:
1. Verify API keys in Supabase dashboard:
   - Go to Settings → API
   - Copy the correct `anon public` key
   - Ensure URL format: `https://your-project-id.supabase.co`

2. Check environment variables:
```env
VITE_SUPABASE_URL=https://your-project-id.supabase.co
VITE_SUPABASE_ANON_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
```

3. Regenerate keys if compromised:
   - Go to Settings → API
   - Click "Regenerate" for affected keys
   - Update environment variables

#### Database schema errors

**Problem**: Tables not found or missing columns

**Solution**:
1. Run the complete schema:
```sql
-- In Supabase SQL Editor
-- Copy and paste contents of database/schema.sql
-- Execute the entire script
```

2. Verify tables exist:
```sql
-- Check if all tables exist
SELECT table_name 
FROM information_schema.tables 
WHERE table_schema = 'public';
```

3. Check RLS policies:
```sql
-- Run RLS policies
-- Copy and paste contents of database/rls-policies.sql
```

#### Row Level Security (RLS) blocking queries

**Problem**: "Insufficient privileges" or empty results

**Solution**:
1. Check if RLS is properly configured:
```sql
-- Verify RLS is enabled
SELECT schemaname, tablename, rowsecurity 
FROM pg_tables 
WHERE schemaname = 'public';
```

2. Test policies with specific user:
```sql
-- Test as authenticated user
SET SESSION ROLE authenticated;
SET SESSION "request.jwt.claims" TO '{"sub":"user-uuid-here"}';

-- Run your query
SELECT * FROM profiles WHERE id = 'user-uuid-here';

-- Reset
RESET ROLE;
```

3. Debug policy conflicts:
   - Check policy conditions
   - Verify user authentication state
   - Test with simplified policies first

## Authentication Issues

### Sign-up/Sign-in Problems

#### Email confirmation not working

**Problem**: Users not receiving confirmation emails

**Solution**:
1. Check Supabase email settings:
   - Go to Authentication → Settings
   - Verify SMTP configuration
   - Test email delivery

2. Configure redirect URLs:
```bash
# Add to Supabase Auth settings
http://localhost:5173/auth/callback
https://your-domain.com/auth/callback
```

3. Handle email confirmation in your app:
```typescript
// In auth callback page
useEffect(() => {
  const handleAuthCallback = async () => {
    const { data, error } = await supabase.auth.getSession();
    if (error) {
      console.error('Auth error:', error);
      // Handle error
    } else if (data.session) {
      // User is authenticated
      router.push('/dashboard');
    }
  };
  
  handleAuthCallback();
}, []);
```

#### Session not persisting

**Problem**: Users logged out on page refresh

**Solution**:
1. Check if you're calling `supabase.auth.getSession()` on app load:
```typescript
// In your auth context
useEffect(() => {
  // Get initial session
  supabase.auth.getSession().then(({ data: { session } }) => {
    setSession(session);
  });

  // Listen for auth changes
  const { data: { subscription } } = supabase.auth.onAuthStateChange(
    (_event, session) => {
      setSession(session);
    }
  );

  return () => subscription.unsubscribe();
}, []);
```

2. Verify localStorage is working:
   - Check browser developer tools → Application → Local Storage
   - Look for Supabase auth tokens

### Profile Creation Issues

#### Profile not created after signup

**Problem**: User authenticated but no profile record

**Solution**:
1. Check if the trigger function exists:
```sql
-- Verify trigger function
SELECT proname FROM pg_proc WHERE proname = 'handle_new_user';

-- Recreate if missing
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO public.profiles (id, username)
  VALUES (
    NEW.id,
    COALESCE(NEW.raw_user_meta_data->>'username', 'Player_' || substr(NEW.id::text, 1, 8))
  );
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;
```

2. Manually create profiles for existing users:
```sql
-- Create missing profiles
INSERT INTO public.profiles (id, username)
SELECT 
  au.id,
  COALESCE(au.raw_user_meta_data->>'username', 'Player_' || substr(au.id::text, 1, 8))
FROM auth.users au
LEFT JOIN public.profiles p ON au.id = p.id
WHERE p.id IS NULL;
```

## Real-time Problems

### Real-time Subscriptions Not Working

#### Game state updates not syncing

**Problem**: Players not seeing real-time updates

**Solution**:
1. Enable real-time in Supabase:
   - Go to Database → Replication
   - Enable real-time for `game_states`, `games`, `game_rooms`
   - Set appropriate filters

2. Check subscription code:
```typescript
// Ensure proper subscription setup
const subscription = supabase
  .channel(`game-state-${gameId}`)
  .on(
    'postgres_changes',
    {
      event: '*',
      schema: 'public',
      table: 'game_states',
      filter: `game_id=eq.${gameId}`,
    },
    (payload) => {
      console.log('Real-time update:', payload);
      // Handle update
    }
  )
  .subscribe();

// Clean up subscription
return () => {
  supabase.removeChannel(subscription);
};
```

3. Debug subscription status:
```typescript
// Check subscription status
subscription.subscribe((status) => {
  console.log('Subscription status:', status);
});
```

#### Too many subscriptions error

**Problem**: "Maximum subscriptions exceeded"

**Solution**:
1. Properly clean up subscriptions:
```typescript
useEffect(() => {
  const subscription = supabase.channel('game-updates');
  // ... setup subscription
  
  return () => {
    // Always clean up
    supabase.removeChannel(subscription);
  };
}, [dependency]);
```

2. Limit subscriptions:
   - Use single channel for multiple updates
   - Unsubscribe when components unmount
   - Share subscriptions between components when possible

## Deployment Issues

### Build Failures

#### Out of memory during build

**Problem**: Build process crashes with memory error

**Solution**:
1. Increase Node.js memory limit:
```json
// package.json
{
  "scripts": {
    "build": "NODE_OPTIONS=--max_old_space_size=4096 vite build"
  }
}
```

2. Optimize build configuration:
```typescript
// vite.config.ts
export default defineConfig({
  build: {
    rollupOptions: {
      output: {
        manualChunks: {
          vendor: ['react', 'react-dom'],
          supabase: ['@supabase/supabase-js'],
        },
      },
    },
  },
});
```

#### Environment variables not working in production

**Problem**: App works locally but fails in production

**Solution**:
1. Set environment variables in deployment platform:

**Vercel**:
- Go to Project Settings → Environment Variables
- Add `VITE_SUPABASE_URL` and `VITE_SUPABASE_ANON_KEY`
- Redeploy the project

**Netlify**:
- Go to Site Settings → Environment Variables
- Add variables and redeploy

2. Verify variables are accessible:
```typescript
// Add debug logging (remove in production)
console.log('Supabase URL:', import.meta.env.VITE_SUPABASE_URL);
console.log('Environment:', import.meta.env.MODE);
```

### CORS Issues

#### API requests blocked by CORS

**Problem**: "Cross-Origin Request Blocked"

**Solution**:
1. Configure Supabase CORS:
   - Add your domain to allowed origins in Supabase
   - Include both www and non-www versions

2. Check request headers:
```typescript
// Ensure proper headers
const { data, error } = await supabase
  .from('table')
  .select('*');
```

## Game-specific Problems

### Movement Lag or Unresponsive Controls

#### Keyboard controls not working

**Problem**: WASD/Arrow keys not moving player

**Solution**:
1. Check if controls are enabled:
```typescript
// Verify useKeyboardControls is properly set up
useKeyboardControls({
  onMove: movePlayer,
  enabled: isGameActive && !!myPlayerId,
});
```

2. Ensure event listeners are attached:
```typescript
// Check if the component is focused
useEffect(() => {
  // Focus the game area for keyboard events
  document.getElementById('game-container')?.focus();
}, []);
```

3. Debug key events:
```typescript
// Add temporary debugging
const handleKeyDown = (e: KeyboardEvent) => {
  console.log('Key pressed:', e.code);
};

useEffect(() => {
  document.addEventListener('keydown', handleKeyDown);
  return () => document.removeEventListener('keydown', handleKeyDown);
}, []);
```

#### Touch controls not working on mobile

**Problem**: Swipe gestures not registering

**Solution**:
1. Ensure touch events are enabled:
```typescript
// Check touchstart/touchend handlers
useTouchControls({
  onMove: movePlayer,
  enabled: isGameActive && !!myPlayerId,
});
```

2. Prevent default touch behavior:
```css
/* In your CSS */
.game-container {
  touch-action: none;
  -webkit-touch-callout: none;
  -webkit-user-select: none;
  user-select: none;
}
```

### Game State Synchronization Issues

#### Players out of sync

**Problem**: Different players see different game states

**Solution**:
1. Add conflict resolution:
```typescript
// Handle conflicting updates
const resolveConflict = (localState: GameState, remoteState: GameState) => {
  // Use server timestamp as authority
  return remoteState.lastUpdated > localState.lastUpdated 
    ? remoteState 
    : localState;
};
```

2. Implement periodic sync:
```typescript
// Sync every few seconds
useEffect(() => {
  const interval = setInterval(async () => {
    const currentState = await gameService.getGameState(gameId);
    if (currentState) {
      setGameState(currentState);
    }
  }, 5000);
  
  return () => clearInterval(interval);
}, [gameId]);
```

## Performance Issues

### Slow Rendering

#### Game board lag during updates

**Problem**: Choppy animations or slow grid updates

**Solution**:
1. Optimize React renders:
```typescript
// Memoize expensive calculations
const gridCells = useMemo(() => {
  return Array.from({ length: gridSize * gridSize }, (_, i) => ({
    x: i % gridSize,
    y: Math.floor(i / gridSize),
  }));
}, [gridSize]);

// Memoize components
const GameCell = React.memo(({ x, y, owner }: CellProps) => {
  // Component implementation
});
```

2. Throttle updates:
```typescript
// Limit update frequency
const throttledUpdate = useCallback(
  throttle((newState: GameState) => {
    setGameState(newState);
  }, 100), // Update at most every 100ms
  []
);
```

3. Use CSS transforms instead of layout changes:
```css
/* Use transform for animations */
.player-avatar {
  transform: translate(var(--x), var(--y));
  transition: transform 0.1s ease-out;
}
```

### Memory Leaks

#### App slowing down over time

**Problem**: Memory usage increasing during gameplay

**Solution**:
1. Clean up subscriptions and timers:
```typescript
useEffect(() => {
  const timer = setInterval(() => {
    // Timer logic
  }, 1000);
  
  const subscription = supabase.channel('updates');
  
  return () => {
    clearInterval(timer);
    supabase.removeChannel(subscription);
  };
}, []);
```

2. Avoid creating new objects in render:
```typescript
// ❌ Creates new object every render
const style = { backgroundColor: player.color };

// ✅ Memoize or move outside component
const style = useMemo(() => ({
  backgroundColor: player.color
}), [player.color]);
```

## Browser Compatibility

### Safari Issues

#### WebSocket connections failing

**Problem**: Real-time features not working in Safari

**Solution**:
1. Check Safari version compatibility
2. Add WebSocket polyfill if needed:
```bash
pnpm add ws
```

3. Use WebRTC fallback for Safari < 14

### Mobile Browser Issues

#### Viewport problems on mobile

**Problem**: Game UI cut off or improperly sized

**Solution**:
1. Add proper viewport meta tag:
```html
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
```

2. Handle safe areas:
```css
.game-container {
  padding-top: env(safe-area-inset-top);
  padding-bottom: env(safe-area-inset-bottom);
}
```

## Getting Help

If you can't find a solution here:

1. **Check logs**:
   - Browser console (F12)
   - Supabase logs in dashboard
   - Network tab for failed requests

2. **Create minimal reproduction**:
   - Isolate the problem
   - Create simple test case
   - Share relevant code snippets

3. **Search for similar issues**:
   - GitHub issues in related projects
   - Stack Overflow with relevant tags
   - Supabase community discussions

4. **Contact support**:
   - Supabase Discord community
   - React community forums
   - Project GitHub issues

---

**Remember**: Most issues are caused by configuration problems, missing environment variables, or authentication setup. Start with the basics and work your way up to more complex problems.