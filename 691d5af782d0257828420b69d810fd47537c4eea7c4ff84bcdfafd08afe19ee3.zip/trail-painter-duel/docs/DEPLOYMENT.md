# Deployment Guide

**Complete deployment instructions for Trail Painter Duel**

This guide will walk you through deploying Trail Painter Duel to production, including backend setup with Supabase and frontend deployment to various platforms.

## Table of Contents

- [Prerequisites](#prerequisites)
- [Supabase Setup](#supabase-setup)
- [Database Configuration](#database-configuration)
- [Environment Variables](#environment-variables)
- [Frontend Deployment](#frontend-deployment)
- [Custom Domain Setup](#custom-domain-setup)
- [Alternative Backends](#alternative-backends)
- [Monitoring & Analytics](#monitoring--analytics)

## Prerequisites

### Required Accounts
- [Supabase](https://supabase.com) account (free tier available)
- [Vercel](https://vercel.com) or [Netlify](https://netlify.com) account (free tier available)
- [GitHub](https://github.com) account for code repository
- Domain registrar account (optional, for custom domain)

### Local Development Tools
- Node.js 18.0 or higher
- pnpm package manager
- Git version control
- Code editor (VS Code recommended)

## Supabase Setup

### 1. Create Supabase Project

1. Go to [Supabase Dashboard](https://app.supabase.com)
2. Click "New Project"
3. Choose your organization or create a new one
4. Fill in project details:
   - **Name**: `trail-painter-duel`
   - **Database Password**: Use a strong password (save this!)
   - **Region**: Choose closest to your target users
5. Click "Create new project"
6. Wait for project initialization (2-3 minutes)

### 2. Get Project Credentials

Once your project is ready:

1. Go to **Settings** → **API**
2. Copy the following values:
   - **Project URL**: `https://your-project-id.supabase.co`
   - **anon public key**: `eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...`
   - **service_role secret key**: `eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...`

⚠️ **Important**: Never expose the service_role key in your frontend code!

### 3. Configure Authentication

1. Go to **Authentication** → **Settings**
2. Configure **Site URL**: `https://your-domain.com`
3. Add **Redirect URLs** (for development and production):
   - `http://localhost:5173/auth/callback`
   - `https://your-domain.com/auth/callback`
4. Enable **Email confirmations** if desired
5. Customize **Email templates** (optional)

## Database Configuration

### 1. Run Database Schema

1. Go to **SQL Editor** in Supabase dashboard
2. Create a new query
3. Copy and paste the contents of `database/schema.sql`
4. Click **Run** to execute the schema

### 2. Set Up Row Level Security (RLS)

1. In SQL Editor, run the RLS policies from `database/rls-policies.sql`
2. Verify that RLS is enabled for all tables
3. Test policies with sample data

### 3. Configure Real-time

1. Go to **Database** → **Replication**
2. Enable real-time for these tables:
   - `game_states`
   - `game_rooms`
   - `games`
3. Set up table-level permissions

## Environment Variables

### 1. Create Environment Files

**For local development** (`.env.local`):
```env
# Supabase Configuration
VITE_SUPABASE_URL=https://your-project-id.supabase.co
VITE_SUPABASE_ANON_KEY=your_anon_key_here

# Optional: Analytics
VITE_GOOGLE_ANALYTICS_ID=G-XXXXXXXXXX

# Optional: Error Tracking
VITE_SENTRY_DSN=https://xxx@xxx.ingest.sentry.io/xxx
```

**For production** (set in deployment platform):
```env
VITE_SUPABASE_URL=https://your-project-id.supabase.co
VITE_SUPABASE_ANON_KEY=your_anon_key_here
VITE_APP_URL=https://your-domain.com
```

### 2. Security Considerations

- **Never commit** `.env.local` to version control
- Use **environment-specific** values for different stages
- **Rotate keys** regularly for production
- Use **preview deployments** for testing

## Frontend Deployment

### Option 1: Vercel Deployment (Recommended)

#### Automatic Deployment

1. **Connect Repository**:
   - Go to [Vercel Dashboard](https://vercel.com/dashboard)
   - Click "New Project"
   - Import your GitHub repository
   - Select the `trail-painter-duel` repository

2. **Configure Project**:
   - **Framework Preset**: Vite
   - **Root Directory**: `./` (keep default)
   - **Build Command**: `pnpm build`
   - **Output Directory**: `dist`
   - **Install Command**: `pnpm install`

3. **Set Environment Variables**:
   - Add your Supabase credentials
   - Click "Deploy"

4. **Custom Domain** (optional):
   - Go to project **Settings** → **Domains**
   - Add your custom domain
   - Configure DNS records as instructed

#### Manual Deployment

```bash
# Install Vercel CLI
npm i -g vercel

# Login to Vercel
vercel login

# Deploy from project directory
vercel

# Follow prompts to configure deployment
# Set environment variables when prompted

# For production deployment
vercel --prod
```

### Option 2: Netlify Deployment

#### Automatic Deployment

1. **Connect Repository**:
   - Go to [Netlify Dashboard](https://app.netlify.com)
   - Click "New site from Git"
   - Choose GitHub and select your repository

2. **Configure Build Settings**:
   - **Build command**: `pnpm build`
   - **Publish directory**: `dist`
   - **Environment variables**: Add Supabase credentials

3. **Deploy Site**:
   - Click "Deploy site"
   - Wait for build to complete
   - Configure custom domain if needed

#### Manual Deployment

```bash
# Install Netlify CLI
npm install -g netlify-cli

# Build the project
pnpm build

# Deploy to Netlify
netlify deploy

# For production deployment
netlify deploy --prod
```

### Option 3: GitHub Pages

1. **Install gh-pages**:
   ```bash
   pnpm add -D gh-pages
   ```

2. **Add deploy script** to `package.json`:
   ```json
   {
     "scripts": {
       "deploy": "pnpm build && gh-pages -d dist"
     }
   }
   ```

3. **Deploy**:
   ```bash
   pnpm deploy
   ```

4. **Configure GitHub Pages**:
   - Go to repository **Settings** → **Pages**
   - Source: Deploy from a branch
   - Branch: `gh-pages`

## Custom Domain Setup

### 1. Purchase Domain

Recommended registrars:
- [Namecheap](https://namecheap.com)
- [Cloudflare](https://cloudflare.com)
- [Google Domains](https://domains.google)

### 2. Configure DNS

**For Vercel**:
```
Type: CNAME
Name: www
Value: cname.vercel-dns.com

Type: A
Name: @
Value: 76.76.19.61
```

**For Netlify**:
```
Type: CNAME
Name: www
Value: your-site-name.netlify.app

Type: A
Name: @
Value: 75.2.60.5
```

### 3. SSL Configuration

Both Vercel and Netlify provide automatic SSL certificates. After domain configuration:

1. Wait for DNS propagation (up to 48 hours)
2. SSL certificate will be automatically issued
3. Force HTTPS redirects will be enabled

## Alternative Backends

If you prefer not to use Supabase, here are alternative backend options:

### Option 1: Node.js + Express + PostgreSQL

1. **Set up server**:
   ```bash
   mkdir trail-painter-server
   cd trail-painter-server
   npm init -y
   npm install express pg socket.io bcryptjs jsonwebtoken
   ```

2. **Database setup**:
   - Use PostgreSQL with the same schema
   - Implement real-time with Socket.IO
   - Deploy to Railway, Heroku, or DigitalOcean

3. **Authentication**:
   - Implement JWT-based authentication
   - Use bcrypt for password hashing
   - Set up CORS for frontend requests

### Option 2: Firebase

1. **Create Firebase project**
2. **Enable services**:
   - Firestore Database
   - Authentication
   - Hosting
3. **Configure real-time**:
   - Use Firestore real-time listeners
   - Implement game state synchronization

### Option 3: AWS Amplify

1. **Install Amplify CLI**:
   ```bash
   npm install -g @aws-amplify/cli
   amplify configure
   ```

2. **Initialize project**:
   ```bash
   amplify init
   amplify add auth
   amplify add api
   amplify push
   ```

3. **Deploy**:
   ```bash
   amplify publish
   ```

## Monitoring & Analytics

### 1. Error Tracking

**Sentry Integration**:
```bash
pnpm add @sentry/react @sentry/tracing
```

**Configuration**:
```typescript
import * as Sentry from '@sentry/react';

Sentry.init({
  dsn: import.meta.env.VITE_SENTRY_DSN,
  environment: import.meta.env.MODE,
});
```

### 2. Analytics

**Google Analytics 4**:
```bash
pnpm add gtag
```

**Implementation**:
```typescript
import { gtag } from 'gtag';

gtag('config', import.meta.env.VITE_GA_MEASUREMENT_ID);
```

### 3. Performance Monitoring

**Web Vitals**:
```bash
pnpm add web-vitals
```

**Usage**:
```typescript
import { getCLS, getFID, getFCP, getLCP, getTTFB } from 'web-vitals';

getCLS(console.log);
getFID(console.log);
getFCP(console.log);
getLCP(console.log);
getTTFB(console.log);
```

## Production Checklist

### Pre-deployment
- [ ] All environment variables configured
- [ ] Database schema and RLS policies applied
- [ ] Real-time subscriptions tested
- [ ] Authentication flow working
- [ ] Game mechanics functioning correctly
- [ ] Mobile responsiveness verified
- [ ] Cross-browser testing completed
- [ ] Error boundaries implemented
- [ ] Loading states for all async operations

### Post-deployment
- [ ] SSL certificate active
- [ ] Custom domain resolving correctly
- [ ] Real-time features working in production
- [ ] User registration and login functional
- [ ] Game rooms creating and joining properly
- [ ] Leaderboard updating correctly
- [ ] Mobile touch controls working
- [ ] Performance metrics acceptable
- [ ] Error tracking configured
- [ ] Analytics implemented

### Security
- [ ] RLS policies tested and secure
- [ ] API keys properly protected
- [ ] CORS configured correctly
- [ ] Rate limiting implemented (if needed)
- [ ] Input validation on all forms
- [ ] XSS protection enabled
- [ ] CSRF protection configured

## Troubleshooting

For common deployment issues and solutions, see [TROUBLESHOOTING.md](TROUBLESHOOTING.md).

## Support

If you encounter issues during deployment:

1. Check the [troubleshooting guide](TROUBLESHOOTING.md)
2. Review Supabase logs in the dashboard
3. Check browser console for frontend errors
4. Verify environment variables are set correctly
5. Test database connections and queries

---

**Congratulations!** 🎉 Your Trail Painter Duel game is now live and ready for players worldwide!

Remember to:
- Monitor performance and user feedback
- Keep dependencies updated
- Back up your database regularly
- Scale infrastructure as your user base grows