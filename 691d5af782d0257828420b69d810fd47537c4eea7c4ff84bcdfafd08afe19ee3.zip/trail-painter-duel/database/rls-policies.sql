-- Row Level Security (RLS) Policies
-- Trail Painter Duel
-- Security policies for data access control

-- =============================================
-- Profiles Table Policies
-- =============================================

-- Users can view all profiles (for leaderboard, usernames, etc.)
CREATE POLICY "Profiles are viewable by everyone" ON public.profiles
    FOR SELECT USING (true);

-- Users can only update their own profile
CREATE POLICY "Users can update own profile" ON public.profiles
    FOR UPDATE USING (auth.uid() = id);

-- Users can insert their own profile (handled by trigger)
CREATE POLICY "Users can insert own profile" ON public.profiles
    FOR INSERT WITH CHECK (auth.uid() = id);

-- Users cannot delete profiles (handled by cascade from auth.users)
CREATE POLICY "Profiles cannot be deleted by users" ON public.profiles
    FOR DELETE USING (false);

-- =============================================
-- Game Rooms Table Policies
-- =============================================

-- Anyone can view non-private game rooms
CREATE POLICY "Public game rooms are viewable by everyone" ON public.game_rooms
    FOR SELECT USING (
        auth.role() = 'authenticated' AND (
            (settings->>'isPrivate')::boolean = false OR 
            creator_id = auth.uid()
        )
    );

-- Authenticated users can create game rooms
CREATE POLICY "Authenticated users can create game rooms" ON public.game_rooms
    FOR INSERT WITH CHECK (
        auth.role() = 'authenticated' AND 
        creator_id = auth.uid()
    );

-- Room creators can update their own rooms
CREATE POLICY "Room creators can update their own rooms" ON public.game_rooms
    FOR UPDATE USING (
        auth.role() = 'authenticated' AND 
        creator_id = auth.uid()
    );

-- Room creators can delete their own rooms
CREATE POLICY "Room creators can delete their own rooms" ON public.game_rooms
    FOR DELETE USING (
        auth.role() = 'authenticated' AND 
        creator_id = auth.uid()
    );

-- =============================================
-- Games Table Policies
-- =============================================

-- Players can view games they're involved in
CREATE POLICY "Players can view their own games" ON public.games
    FOR SELECT USING (
        auth.role() = 'authenticated' AND (
            player1_id = auth.uid() OR 
            player2_id = auth.uid()
        )
    );

-- System can create games (typically done by room creator)
CREATE POLICY "Authenticated users can create games" ON public.games
    FOR INSERT WITH CHECK (
        auth.role() = 'authenticated' AND (
            player1_id = auth.uid() OR 
            -- Allow creating games for other players (room creator functionality)
            EXISTS (
                SELECT 1 FROM public.game_rooms 
                WHERE id = room_id AND creator_id = auth.uid()
            )
        )
    );

-- Players can update games they're involved in
CREATE POLICY "Players can update their own games" ON public.games
    FOR UPDATE USING (
        auth.role() = 'authenticated' AND (
            player1_id = auth.uid() OR 
            player2_id = auth.uid()
        )
    );

-- Players cannot delete games (preserve match history)
CREATE POLICY "Games cannot be deleted by players" ON public.games
    FOR DELETE USING (false);

-- =============================================
-- Game States Table Policies
-- =============================================

-- Players can view game states for their games
CREATE POLICY "Players can view game states for their games" ON public.game_states
    FOR SELECT USING (
        auth.role() = 'authenticated' AND 
        EXISTS (
            SELECT 1 FROM public.games g 
            WHERE g.id = game_id AND (
                g.player1_id = auth.uid() OR 
                g.player2_id = auth.uid()
            )
        )
    );

-- Players can create game states for their games
CREATE POLICY "Players can create game states for their games" ON public.game_states
    FOR INSERT WITH CHECK (
        auth.role() = 'authenticated' AND 
        EXISTS (
            SELECT 1 FROM public.games g 
            WHERE g.id = game_id AND (
                g.player1_id = auth.uid() OR 
                g.player2_id = auth.uid()
            )
        )
    );

-- Players can update game states for their games
CREATE POLICY "Players can update game states for their games" ON public.game_states
    FOR UPDATE USING (
        auth.role() = 'authenticated' AND 
        EXISTS (
            SELECT 1 FROM public.games g 
            WHERE g.id = game_id AND (
                g.player1_id = auth.uid() OR 
                g.player2_id = auth.uid()
            )
        )
    );

-- Game states cannot be deleted (preserve game history)
CREATE POLICY "Game states cannot be deleted" ON public.game_states
    FOR DELETE USING (false);

-- =============================================
-- Match History Table Policies
-- =============================================

-- Users can view their own match history
CREATE POLICY "Users can view their own match history" ON public.match_history
    FOR SELECT USING (
        auth.role() = 'authenticated' AND 
        player_id = auth.uid()
    );

-- System can create match history records
CREATE POLICY "System can create match history" ON public.match_history
    FOR INSERT WITH CHECK (
        auth.role() = 'authenticated' AND (
            player_id = auth.uid() OR
            -- Allow creating history for games the user participated in
            EXISTS (
                SELECT 1 FROM public.games g 
                WHERE g.id = game_id AND (
                    g.player1_id = auth.uid() OR 
                    g.player2_id = auth.uid()
                )
            )
        )
    );

-- Match history cannot be updated or deleted (preserve integrity)
CREATE POLICY "Match history cannot be updated" ON public.match_history
    FOR UPDATE USING (false);

CREATE POLICY "Match history cannot be deleted" ON public.match_history
    FOR DELETE USING (false);

-- =============================================
-- View Policies
-- =============================================

-- Leaderboard is public (anyone can view)
GRANT SELECT ON public.leaderboard TO anon;
GRANT SELECT ON public.leaderboard TO authenticated;

-- Active games view is for authenticated users only
GRANT SELECT ON public.active_games TO authenticated;

-- =============================================
-- Additional Security Functions
-- =============================================

-- Function to check if user is involved in a game
CREATE OR REPLACE FUNCTION public.user_involved_in_game(game_uuid UUID)
RETURNS BOOLEAN AS $$
BEGIN
    RETURN EXISTS (
        SELECT 1 FROM public.games 
        WHERE id = game_uuid AND (
            player1_id = auth.uid() OR 
            player2_id = auth.uid()
        )
    );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Function to check if user owns a room
CREATE OR REPLACE FUNCTION public.user_owns_room(room_uuid UUID)
RETURNS BOOLEAN AS $$
BEGIN
    RETURN EXISTS (
        SELECT 1 FROM public.game_rooms 
        WHERE id = room_uuid AND creator_id = auth.uid()
    );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- =============================================
-- Rate Limiting (Optional)
-- =============================================

-- Create a simple rate limiting table
CREATE TABLE IF NOT EXISTS public.rate_limits (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
    action VARCHAR(50) NOT NULL,
    count INTEGER DEFAULT 1,
    window_start TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Enable RLS on rate limits
ALTER TABLE public.rate_limits ENABLE ROW LEVEL SECURITY;

-- Rate limit policies
CREATE POLICY "Users can view their own rate limits" ON public.rate_limits
    FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "Users can insert their own rate limits" ON public.rate_limits
    FOR INSERT WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own rate limits" ON public.rate_limits
    FOR UPDATE USING (auth.uid() = user_id);

-- Function to check rate limits
CREATE OR REPLACE FUNCTION public.check_rate_limit(
    action_name VARCHAR(50),
    max_requests INTEGER DEFAULT 10,
    window_minutes INTEGER DEFAULT 1
)
RETURNS BOOLEAN AS $$
DECLARE
    current_count INTEGER;
    window_start TIMESTAMP WITH TIME ZONE;
BEGIN
    -- Check if user is authenticated
    IF auth.uid() IS NULL THEN
        RETURN false;
    END IF;
    
    -- Calculate window start
    window_start := NOW() - (window_minutes || ' minutes')::INTERVAL;
    
    -- Get current count for this action in the time window
    SELECT COALESCE(SUM(count), 0) INTO current_count
    FROM public.rate_limits
    WHERE user_id = auth.uid()
        AND action = action_name
        AND window_start > window_start;
    
    -- Check if limit exceeded
    IF current_count >= max_requests THEN
        RETURN false;
    END IF;
    
    -- Record this request
    INSERT INTO public.rate_limits (user_id, action, window_start)
    VALUES (auth.uid(), action_name, NOW())
    ON CONFLICT DO NOTHING;
    
    RETURN true;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- =============================================
-- Audit Trail (Optional)
-- =============================================

-- Create audit table for sensitive operations
CREATE TABLE IF NOT EXISTS public.audit_log (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID REFERENCES auth.users(id),
    table_name VARCHAR(50) NOT NULL,
    operation VARCHAR(10) NOT NULL CHECK (operation IN ('INSERT', 'UPDATE', 'DELETE')),
    old_data JSONB,
    new_data JSONB,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Enable RLS on audit log
ALTER TABLE public.audit_log ENABLE ROW LEVEL SECURITY;

-- Only admins can view audit logs (adjust as needed)
CREATE POLICY "Only service role can access audit log" ON public.audit_log
    USING (auth.role() = 'service_role');

-- Function to log changes
CREATE OR REPLACE FUNCTION public.audit_changes()
RETURNS TRIGGER AS $$
BEGIN
    INSERT INTO public.audit_log (user_id, table_name, operation, old_data, new_data)
    VALUES (
        auth.uid(),
        TG_TABLE_NAME,
        TG_OP,
        CASE WHEN TG_OP = 'DELETE' THEN row_to_json(OLD) ELSE NULL END,
        CASE WHEN TG_OP = 'INSERT' OR TG_OP = 'UPDATE' THEN row_to_json(NEW) ELSE NULL END
    );
    
    RETURN CASE WHEN TG_OP = 'DELETE' THEN OLD ELSE NEW END;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Add audit triggers to important tables (optional)
/*
CREATE TRIGGER audit_games_changes
    AFTER INSERT OR UPDATE OR DELETE ON public.games
    FOR EACH ROW EXECUTE FUNCTION public.audit_changes();

CREATE TRIGGER audit_profiles_changes
    AFTER UPDATE ON public.profiles
    FOR EACH ROW EXECUTE FUNCTION public.audit_changes();
*/

-- =============================================
-- Test RLS Policies
-- =============================================

-- Function to test RLS policies (development only)
CREATE OR REPLACE FUNCTION public.test_rls_policies()
RETURNS TEXT AS $$
DECLARE
    result TEXT := 'RLS Policy Tests:';
BEGIN
    -- Test that RLS is enabled on all tables
    IF NOT EXISTS (
        SELECT 1 FROM pg_class c
        JOIN pg_namespace n ON n.oid = c.relnamespace
        WHERE n.nspname = 'public'
        AND c.relname = 'profiles'
        AND c.relrowsecurity = true
    ) THEN
        result := result || E'\n❌ RLS not enabled on profiles table';
    ELSE
        result := result || E'\n✅ RLS enabled on profiles table';
    END IF;
    
    -- Add more tests as needed...
    
    RETURN result;
END;
$$ LANGUAGE plpgsql;

-- =============================================
-- Cleanup (Optional)
-- =============================================

-- Function to clean up old rate limit records
CREATE OR REPLACE FUNCTION public.cleanup_rate_limits()
RETURNS INTEGER AS $$
DECLARE
    deleted_count INTEGER;
BEGIN
    DELETE FROM public.rate_limits
    WHERE created_at < NOW() - INTERVAL '24 hours';
    
    GET DIAGNOSTICS deleted_count = ROW_COUNT;
    RETURN deleted_count;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Function to clean up old audit logs
CREATE OR REPLACE FUNCTION public.cleanup_audit_logs(days_to_keep INTEGER DEFAULT 90)
RETURNS INTEGER AS $$
DECLARE
    deleted_count INTEGER;
BEGIN
    DELETE FROM public.audit_log
    WHERE created_at < NOW() - (days_to_keep || ' days')::INTERVAL;
    
    GET DIAGNOSTICS deleted_count = ROW_COUNT;
    RETURN deleted_count;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- =============================================
-- Final Security Check
-- =============================================

-- Verify all tables have RLS enabled
DO $$
DECLARE
    table_record RECORD;
    tables_without_rls TEXT[];
BEGIN
    -- Check all public tables for RLS
    FOR table_record IN
        SELECT schemaname, tablename
        FROM pg_tables
        WHERE schemaname = 'public'
        AND tablename NOT LIKE 'pg_%'
        AND tablename NOT LIKE 'sql_%'
    LOOP
        IF NOT EXISTS (
            SELECT 1 FROM pg_class c
            JOIN pg_namespace n ON n.oid = c.relnamespace
            WHERE n.nspname = table_record.schemaname
            AND c.relname = table_record.tablename
            AND c.relrowsecurity = true
        ) THEN
            tables_without_rls := array_append(tables_without_rls, table_record.tablename);
        END IF;
    END LOOP;
    
    IF array_length(tables_without_rls, 1) > 0 THEN
        RAISE WARNING 'Tables without RLS: %', array_to_string(tables_without_rls, ', ');
    ELSE
        RAISE NOTICE 'All tables have RLS enabled ✅';
    END IF;
END
$$;

-- RLS policies setup completed successfully!
-- Next steps:
-- 1. Test policies with different user scenarios
-- 2. Monitor policy performance in production
-- 3. Adjust policies based on application requirements
-- 4. Set up monitoring for security events