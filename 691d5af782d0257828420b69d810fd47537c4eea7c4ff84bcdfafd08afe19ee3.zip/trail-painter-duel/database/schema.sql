-- Trail Painter Duel Database Schema
-- PostgreSQL + Supabase
-- Version: 1.0
-- Created: 2025-01-XX

-- =============================================
-- Enable Required Extensions
-- =============================================

-- Enable UUID generation
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Enable Row Level Security
ALTER DATABASE postgres SET row_security = on;

-- =============================================
-- Create Tables
-- =============================================

-- User Profiles Table
-- Extends Supabase auth.users with game-specific data
CREATE TABLE public.profiles (
    id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
    username VARCHAR(50) UNIQUE NOT NULL,
    avatar_url TEXT,
    games_played INTEGER DEFAULT 0 CHECK (games_played >= 0),
    games_won INTEGER DEFAULT 0 CHECK (games_won >= 0),
    total_territory_painted BIGINT DEFAULT 0 CHECK (total_territory_painted >= 0),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    
    -- Constraints
    CONSTRAINT username_length CHECK (LENGTH(username) >= 3),
    CONSTRAINT valid_wins CHECK (games_won <= games_played)
);

-- Game Rooms Table
-- Manages lobby and room creation system
CREATE TABLE public.game_rooms (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    room_code VARCHAR(10) UNIQUE NOT NULL,
    creator_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
    status VARCHAR(20) DEFAULT 'waiting' CHECK (status IN ('waiting', 'active', 'finished')),
    max_players INTEGER DEFAULT 2 CHECK (max_players > 0 AND max_players <= 10),
    current_players INTEGER DEFAULT 1 CHECK (current_players >= 0),
    settings JSONB DEFAULT '{}',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    
    -- Constraints
    CONSTRAINT valid_player_count CHECK (current_players <= max_players),
    CONSTRAINT room_code_format CHECK (room_code ~ '^[A-Z0-9]{6}$')
);

-- Games Table
-- Individual game sessions and match data
CREATE TABLE public.games (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    room_id UUID NOT NULL REFERENCES public.game_rooms(id) ON DELETE CASCADE,
    player1_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
    player2_id UUID REFERENCES public.profiles(id) ON DELETE CASCADE,
    status VARCHAR(20) DEFAULT 'waiting' CHECK (status IN ('waiting', 'active', 'finished', 'abandoned')),
    current_round INTEGER DEFAULT 1 CHECK (current_round > 0),
    max_rounds INTEGER DEFAULT 3 CHECK (max_rounds > 0 AND max_rounds <= 10),
    player1_score INTEGER DEFAULT 0 CHECK (player1_score >= 0),
    player2_score INTEGER DEFAULT 0 CHECK (player2_score >= 0),
    winner_id UUID REFERENCES public.profiles(id),
    game_settings JSONB DEFAULT '{}',
    started_at TIMESTAMP WITH TIME ZONE,
    ended_at TIMESTAMP WITH TIME ZONE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    
    -- Constraints
    CONSTRAINT different_players CHECK (player1_id != player2_id),
    CONSTRAINT valid_scores CHECK (player1_score <= max_rounds AND player2_score <= max_rounds),
    CONSTRAINT valid_winner CHECK (winner_id IS NULL OR winner_id IN (player1_id, player2_id)),
    CONSTRAINT valid_timeline CHECK (started_at IS NULL OR ended_at IS NULL OR started_at <= ended_at)
);

-- Game States Table
-- Real-time game state for live gameplay
CREATE TABLE public.game_states (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    game_id UUID NOT NULL REFERENCES public.games(id) ON DELETE CASCADE,
    round_number INTEGER NOT NULL CHECK (round_number > 0),
    player1_position JSONB DEFAULT '{"x": 2, "y": 2}',
    player2_position JSONB DEFAULT '{"x": 22, "y": 22}',
    territory_data JSONB DEFAULT '{}',
    round_time_remaining INTEGER DEFAULT 120 CHECK (round_time_remaining >= 0),
    round_status VARCHAR(20) DEFAULT 'active' CHECK (round_status IN ('waiting', 'active', 'paused', 'finished')),
    player1_territory_count INTEGER DEFAULT 0 CHECK (player1_territory_count >= 0),
    player2_territory_count INTEGER DEFAULT 0 CHECK (player2_territory_count >= 0),
    last_updated TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    
    -- Constraints
    CONSTRAINT unique_game_round UNIQUE (game_id, round_number),
    CONSTRAINT valid_territory_total CHECK (player1_territory_count + player2_territory_count <= 625) -- 25x25 grid max
);

-- Match History Table
-- Player statistics and match records
CREATE TABLE public.match_history (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    game_id UUID NOT NULL REFERENCES public.games(id) ON DELETE CASCADE,
    player_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
    opponent_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
    result VARCHAR(10) NOT NULL CHECK (result IN ('win', 'loss', 'draw')),
    final_score INTEGER NOT NULL CHECK (final_score >= 0),
    opponent_score INTEGER NOT NULL CHECK (opponent_score >= 0),
    territory_painted INTEGER DEFAULT 0 CHECK (territory_painted >= 0),
    rounds_won INTEGER DEFAULT 0 CHECK (rounds_won >= 0),
    duration_seconds INTEGER CHECK (duration_seconds > 0),
    played_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    
    -- Constraints
    CONSTRAINT different_players_history CHECK (player_id != opponent_id)
);

-- =============================================
-- Create Indexes for Performance
-- =============================================

-- Profiles indexes
CREATE INDEX idx_profiles_username ON public.profiles(username);
CREATE INDEX idx_profiles_games_won ON public.profiles(games_won DESC);
CREATE INDEX idx_profiles_created_at ON public.profiles(created_at);

-- Game rooms indexes
CREATE INDEX idx_game_rooms_status ON public.game_rooms(status);
CREATE INDEX idx_game_rooms_creator ON public.game_rooms(creator_id);
CREATE INDEX idx_game_rooms_created ON public.game_rooms(created_at DESC);
CREATE INDEX idx_game_rooms_room_code ON public.game_rooms(room_code);

-- Games indexes
CREATE INDEX idx_games_room ON public.games(room_id);
CREATE INDEX idx_games_player1 ON public.games(player1_id);
CREATE INDEX idx_games_player2 ON public.games(player2_id);
CREATE INDEX idx_games_status ON public.games(status);
CREATE INDEX idx_games_created ON public.games(created_at DESC);

-- Game states indexes
CREATE INDEX idx_game_states_game ON public.game_states(game_id);
CREATE INDEX idx_game_states_round ON public.game_states(game_id, round_number);
CREATE INDEX idx_game_states_updated ON public.game_states(last_updated DESC);

-- Match history indexes
CREATE INDEX idx_match_history_player ON public.match_history(player_id);
CREATE INDEX idx_match_history_played_at ON public.match_history(played_at DESC);
CREATE INDEX idx_match_history_game ON public.match_history(game_id);

-- =============================================
-- Create Functions and Triggers
-- =============================================

-- Function to update updated_at timestamp
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ language 'plpgsql';

-- Triggers for updated_at
CREATE TRIGGER update_profiles_updated_at 
    BEFORE UPDATE ON public.profiles 
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_game_rooms_updated_at 
    BEFORE UPDATE ON public.game_rooms 
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- Function to automatically create profile when user signs up
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER AS $$
BEGIN
    INSERT INTO public.profiles (id, username)
    VALUES (
        NEW.id,
        COALESCE(NEW.raw_user_meta_data->>'username', 'Player_' || substr(NEW.id::text, 1, 8))
    );
    RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Trigger to create profile on user signup
CREATE TRIGGER on_auth_user_created
    AFTER INSERT ON auth.users
    FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- Function to validate game state updates
CREATE OR REPLACE FUNCTION validate_game_state_update()
RETURNS TRIGGER AS $$
BEGIN
    -- Ensure game exists and is active
    IF NOT EXISTS (
        SELECT 1 FROM public.games 
        WHERE id = NEW.game_id AND status = 'active'
    ) THEN
        RAISE EXCEPTION 'Cannot update state for inactive game';
    END IF;
    
    -- Update last_updated timestamp
    NEW.last_updated = NOW();
    
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER validate_game_state_before_update
    BEFORE UPDATE ON public.game_states
    FOR EACH ROW EXECUTE FUNCTION validate_game_state_update();

-- =============================================
-- Create Views for Common Queries
-- =============================================

-- Leaderboard view
CREATE VIEW public.leaderboard AS
SELECT 
    p.username,
    p.games_played,
    p.games_won,
    CASE 
        WHEN p.games_played > 0 
        THEN ROUND((p.games_won::decimal / p.games_played::decimal) * 100, 1)
        ELSE 0 
    END as win_rate,
    p.total_territory_painted,
    RANK() OVER (ORDER BY p.games_won DESC, p.games_played ASC) as rank
FROM public.profiles p
WHERE p.games_played > 0
ORDER BY p.games_won DESC, p.games_played ASC;

-- Active games view
CREATE VIEW public.active_games AS
SELECT 
    g.id,
    g.room_id,
    p1.username as player1_username,
    p2.username as player2_username,
    g.current_round,
    g.max_rounds,
    g.player1_score,
    g.player2_score,
    g.started_at,
    gs.round_time_remaining,
    gs.round_status
FROM public.games g
LEFT JOIN public.profiles p1 ON g.player1_id = p1.id
LEFT JOIN public.profiles p2 ON g.player2_id = p2.id
LEFT JOIN public.game_states gs ON g.id = gs.game_id 
    AND gs.round_number = g.current_round
WHERE g.status = 'active';

-- =============================================
-- Enable Row Level Security (RLS)
-- =============================================

-- Enable RLS on all tables
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.game_rooms ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.games ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.game_states ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.match_history ENABLE ROW LEVEL SECURITY;

-- =============================================
-- Grant Permissions
-- =============================================

-- Grant usage on schema
GRANT USAGE ON SCHEMA public TO authenticated;
GRANT USAGE ON SCHEMA public TO anon;

-- Grant permissions on tables
GRANT ALL ON public.profiles TO authenticated;
GRANT ALL ON public.game_rooms TO authenticated;
GRANT ALL ON public.games TO authenticated;
GRANT ALL ON public.game_states TO authenticated;
GRANT ALL ON public.match_history TO authenticated;

-- Grant permissions on views
GRANT SELECT ON public.leaderboard TO authenticated;
GRANT SELECT ON public.leaderboard TO anon;
GRANT SELECT ON public.active_games TO authenticated;

-- =============================================
-- Insert Sample Data (Optional)
-- =============================================

-- Note: This section is for development/testing only
-- Remove or comment out for production deployment

/*
-- Sample game room settings
INSERT INTO public.game_rooms (room_code, creator_id, settings) VALUES 
('DEMO01', (SELECT id FROM auth.users LIMIT 1), '{
    "isPrivate": false,
    "gameSettings": {
        "gridSize": 25,
        "roundDuration": 120,
        "maxRounds": 3,
        "powerUpsEnabled": false
    }
}');
*/

-- =============================================
-- Schema Validation
-- =============================================

-- Verify all tables exist
DO $$
DECLARE
    tables text[] := ARRAY['profiles', 'game_rooms', 'games', 'game_states', 'match_history'];
    table_name text;
BEGIN
    FOREACH table_name IN ARRAY tables
    LOOP
        IF NOT EXISTS (
            SELECT 1 FROM information_schema.tables 
            WHERE table_schema = 'public' 
            AND table_name = table_name
        ) THEN
            RAISE EXCEPTION 'Table % does not exist', table_name;
        END IF;
    END LOOP;
    
    RAISE NOTICE 'All tables created successfully!';
END
$$;

-- =============================================
-- Performance Tuning
-- =============================================

-- Update table statistics
ANALYZE public.profiles;
ANALYZE public.game_rooms;
ANALYZE public.games;
ANALYZE public.game_states;
ANALYZE public.match_history;

-- =============================================
-- Comments for Documentation
-- =============================================

COMMENT ON TABLE public.profiles IS 'User profiles with game statistics';
COMMENT ON TABLE public.game_rooms IS 'Game rooms for matchmaking and lobby system';
COMMENT ON TABLE public.games IS 'Individual game sessions and match results';
COMMENT ON TABLE public.game_states IS 'Real-time game state data for live gameplay';
COMMENT ON TABLE public.match_history IS 'Match history and player statistics tracking';

COMMENT ON COLUMN public.profiles.total_territory_painted IS 'Total cells painted across all games';
COMMENT ON COLUMN public.game_rooms.room_code IS 'Unique 6-character room code for joining';
COMMENT ON COLUMN public.games.game_settings IS 'JSON configuration for game rules and settings';
COMMENT ON COLUMN public.game_states.territory_data IS 'JSON map of painted cells: {"x,y": "player_id"}';
COMMENT ON COLUMN public.match_history.duration_seconds IS 'Total game duration in seconds';

-- Schema creation completed successfully!
-- Next steps:
-- 1. Set up Row Level Security policies (see rls-policies.sql)
-- 2. Configure real-time subscriptions in Supabase dashboard
-- 3. Test the schema with sample data
-- 4. Deploy frontend application with proper environment variables