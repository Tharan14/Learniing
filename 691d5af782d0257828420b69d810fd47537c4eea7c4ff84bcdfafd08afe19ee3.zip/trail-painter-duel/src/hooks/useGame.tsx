import { useState, useEffect, useCallback, useRef } from 'react';
import { GameState, Position, Direction, Player, Game, GameRoom } from '../types';
import { gameService, gameRoomService } from '../services/gameService';
import { GameLogic } from '../game/gameLogic';
import { supabase, subscribeToGameState, subscribeToGame } from '../services/supabase';
import { useAuth } from './useAuth';
import toast from 'react-hot-toast';

interface UseGameReturn {
  // Game state
  game: Game | null;
  gameState: GameState | null;
  gameLogic: GameLogic;
  players: Player[];
  isPlayer1: boolean;
  isPlayer2: boolean;
  myPlayerId: string | null;
  opponentId: string | null;
  
  // Game actions
  movePlayer: (direction: Direction) => Promise<void>;
  leaveGame: () => Promise<void>;
  
  // Game status
  isGameActive: boolean;
  isMyTurn: boolean;
  gameLoading: boolean;
  gameError: string | null;
  
  // Round management
  timeRemaining: number;
  currentRound: number;
  maxRounds: number;
  player1Score: number;
  player2Score: number;
  
  // Territory stats
  myTerritoryCount: number;
  opponentTerritoryCount: number;
  myTerritoryPercentage: number;
  opponentTerritoryPercentage: number;
}

export function useGame(gameId: string | null): UseGameReturn {
  const { user, profile } = useAuth();
  const [game, setGame] = useState<Game | null>(null);
  const [gameState, setGameState] = useState<GameState | null>(null);
  const [players, setPlayers] = useState<Player[]>([]);
  const [gameLoading, setGameLoading] = useState(false);
  const [gameError, setGameError] = useState<string | null>(null);
  const [timeRemaining, setTimeRemaining] = useState(0);
  
  const gameLogicRef = useRef(new GameLogic());
  const gameLogic = gameLogicRef.current;
  const lastMoveTimeRef = useRef(0);
  const timerRef = useRef<NodeJS.Timeout | null>(null);
  
  // Player identification
  const myPlayerId = user?.id || null;
  const isPlayer1 = game?.player1Id === myPlayerId;
  const isPlayer2 = game?.player2Id === myPlayerId;
  const opponentId = isPlayer1 ? game?.player2Id : game?.player1Id;
  
  // Game status
  const isGameActive = game?.status === 'active' && gameState?.roundStatus === 'active';
  const isMyTurn = isGameActive; // In real-time mode, both players can move simultaneously
  
  // Scores and rounds
  const currentRound = game?.currentRound || 1;
  const maxRounds = game?.maxRounds || 3;
  const player1Score = game?.player1Score || 0;
  const player2Score = game?.player2Score || 0;
  
  // Territory calculations
  const myTerritoryCount = isPlayer1 
    ? (gameState?.player1TerritoryCount || 0)
    : (gameState?.player2TerritoryCount || 0);
  const opponentTerritoryCount = isPlayer1 
    ? (gameState?.player2TerritoryCount || 0)
    : (gameState?.player1TerritoryCount || 0);
  
  const totalCells = 25 * 25; // GRID_SIZE * GRID_SIZE
  const myTerritoryPercentage = (myTerritoryCount / totalCells) * 100;
  const opponentTerritoryPercentage = (opponentTerritoryCount / totalCells) * 100;
  
  // Load initial game data
  useEffect(() => {
    if (!gameId || !user) return;
    
    async function loadGame() {
      setGameLoading(true);
      setGameError(null);
      
      try {
        // Load game details
        const { data: gameData, error: gameError } = await supabase
          .from('games')
          .select('*')
          .eq('id', gameId)
          .maybeSingle();
        
        if (gameError || !gameData) {
          setGameError('Game not found');
          return;
        }
        
        setGame(gameData as Game);
        
        // Load current game state
        const currentGameState = await gameService.getGameState(gameId);
        if (currentGameState) {
          setGameState(currentGameState);
          setTimeRemaining(currentGameState.roundTimeRemaining);
          
          // Update game logic with territory data
          gameLogic.setTerritoryData(currentGameState.territoryData);
        }
        
        // Load player profiles
        const playerIds = [gameData.player1_id, gameData.player2_id].filter(Boolean);
        const { data: profiles } = await supabase
          .from('profiles')
          .select('*')
          .in('id', playerIds);
        
        if (profiles) {
          const gamePlayers: Player[] = profiles.map((profile, index) => ({
            id: profile.id,
            username: profile.username,
            color: index === 0 ? '#3B82F6' : '#F59E0B', // Blue for player 1, Orange for player 2
            position: index === 0 
              ? (currentGameState?.player1Position || { x: 2, y: 2 })
              : (currentGameState?.player2Position || { x: 22, y: 22 }),
            territoryCount: index === 0 
              ? (currentGameState?.player1TerritoryCount || 0)
              : (currentGameState?.player2TerritoryCount || 0),
            avatar_url: profile.avatar_url,
          }));
          
          setPlayers(gamePlayers);
        }
      } catch (error) {
        console.error('Error loading game:', error);
        setGameError('Failed to load game');
      } finally {
        setGameLoading(false);
      }
    }
    
    loadGame();
  }, [gameId, user, gameLogic]);
  
  // Set up real-time subscriptions
  useEffect(() => {
    if (!gameId) return;
    
    const gameStateSubscription = subscribeToGameState(gameId, (payload) => {
      if (payload.new) {
        const newGameState = payload.new as GameState;
        setGameState(newGameState);
        setTimeRemaining(newGameState.roundTimeRemaining);
        
        // Update game logic
        gameLogic.setTerritoryData(newGameState.territoryData);
        
        // Update player positions and territory counts
        setPlayers(prev => prev.map(player => {
          if (player.id === game?.player1Id) {
            return {
              ...player,
              position: newGameState.player1Position,
              territoryCount: newGameState.player1TerritoryCount,
            };
          } else if (player.id === game?.player2Id) {
            return {
              ...player,
              position: newGameState.player2Position,
              territoryCount: newGameState.player2TerritoryCount,
            };
          }
          return player;
        }));
      }
    });
    
    const gameSubscription = subscribeToGame(gameId, (payload) => {
      if (payload.new) {
        setGame(payload.new as Game);
        
        // Handle game end
        if (payload.new.status === 'finished') {
          if (timerRef.current) {
            clearInterval(timerRef.current);
          }
          
          const winner = payload.new.winner_id;
          if (winner === myPlayerId) {
            toast.success('Congratulations! You won the game!');
          } else if (winner) {
            toast.error('Game over. Better luck next time!');
          } else {
            toast('Game ended in a draw!');
          }
        }
      }
    });
    
    return () => {
      if (gameStateSubscription) {
        supabase.removeChannel(gameStateSubscription);
      }
      if (gameSubscription) {
        supabase.removeChannel(gameSubscription);
      }
    };
  }, [gameId, game, gameLogic, myPlayerId]);
  
  // Game timer
  useEffect(() => {
    if (!isGameActive || timeRemaining <= 0) {
      if (timerRef.current) {
        clearInterval(timerRef.current);
      }
      return;
    }
    
    timerRef.current = setInterval(() => {
      setTimeRemaining(prev => {
        if (prev <= 1) {
          // Round ended
          if (timerRef.current) {
            clearInterval(timerRef.current);
          }
          handleRoundEnd();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
    
    return () => {
      if (timerRef.current) {
        clearInterval(timerRef.current);
      }
    };
  }, [isGameActive, timeRemaining]);
  
  // Handle round end
  const handleRoundEnd = useCallback(async () => {
    if (!game || !gameState) return;
    
    try {
      const territoryStats = gameLogic.getGameStats(game.player1Id, game.player2Id!);
      const roundResult = gameLogic.determineWinner(game.player1Id, game.player2Id!);
      
      await gameService.endRound(
        game.id,
        roundResult.winnerId,
        {
          player1: territoryStats.player1Territory,
          player2: territoryStats.player2Territory,
        }
      );
      
      // Show round result
      if (roundResult.winnerId === myPlayerId) {
        toast.success(`Round ${currentRound} won!`);
      } else if (roundResult.winnerId) {
        toast.error(`Round ${currentRound} lost.`);
      } else {
        toast('Round ended in a draw!');
      }
    } catch (error) {
      console.error('Error ending round:', error);
      toast.error('Failed to end round');
    }
  }, [game, gameState, gameLogic, myPlayerId, currentRound]);
  
  // Move player function
  const movePlayer = useCallback(async (direction: Direction) => {
    if (!isGameActive || !myPlayerId || !game || !gameState) {
      return;
    }
    
    const now = Date.now();
    if (now - lastMoveTimeRef.current < 100) {
      return; // Rate limiting
    }
    
    try {
      const currentPlayer = players.find(p => p.id === myPlayerId);
      if (!currentPlayer) return;
      
      // Calculate new position
      const newPosition = gameLogic.calculateNewPosition(currentPlayer.position, direction);
      
      // Validate move
      const validation = gameLogic.validateMove(
        currentPlayer.position,
        newPosition,
        lastMoveTimeRef.current
      );
      
      if (!validation.isValid) {
        return;
      }
      
      // Apply move to game logic
      const moveResult = gameLogic.movePlayer(myPlayerId, currentPlayer.position, direction);
      
      if (moveResult.territoryPainted) {
        // Update territory counts
        const territoryStats = gameLogic.getGameStats(game.player1Id, game.player2Id!);
        
        // Send update to database
        await gameService.updatePlayerPosition(
          game.id,
          myPlayerId,
          moveResult.newPosition,
          gameLogic.getTerritoryData(),
          {
            player1: territoryStats.player1Territory,
            player2: territoryStats.player2Territory,
          }
        );
        
        lastMoveTimeRef.current = now;
      }
    } catch (error) {
      console.error('Error moving player:', error);
      toast.error('Failed to move');
    }
  }, [isGameActive, myPlayerId, game, gameState, players, gameLogic]);
  
  // Leave game function
  const leaveGame = useCallback(async () => {
    if (!game || !myPlayerId) return;
    
    try {
      // Update game status to abandoned
      const { error } = await supabase
        .from('games')
        .update({
          status: 'abandoned',
          ended_at: new Date().toISOString(),
        })
        .eq('id', game.id);
      
      if (error) {
        console.error('Error leaving game:', error);
        toast.error('Failed to leave game');
      } else {
        toast.success('Left the game');
      }
    } catch (error) {
      console.error('Error leaving game:', error);
      toast.error('Failed to leave game');
    }
  }, [game, myPlayerId]);
  
  return {
    // Game state
    game,
    gameState,
    gameLogic,
    players,
    isPlayer1,
    isPlayer2,
    myPlayerId,
    opponentId,
    
    // Game actions
    movePlayer,
    leaveGame,
    
    // Game status
    isGameActive,
    isMyTurn,
    gameLoading,
    gameError,
    
    // Round management
    timeRemaining,
    currentRound,
    maxRounds,
    player1Score,
    player2Score,
    
    // Territory stats
    myTerritoryCount,
    opponentTerritoryCount,
    myTerritoryPercentage,
    opponentTerritoryPercentage,
  };
}