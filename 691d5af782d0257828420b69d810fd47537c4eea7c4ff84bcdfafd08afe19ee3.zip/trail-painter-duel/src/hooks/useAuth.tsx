import React, { createContext, useContext, useEffect, useState, ReactNode } from 'react';
import { User } from '@supabase/supabase-js';
import { supabase } from '../services/supabase';
import { authService } from '../services/authService';
import { Profile } from '../types';

interface AuthContextType {
  user: User | null;
  profile: Profile | null;
  loading: boolean;
  signIn: (email: string, password: string) => Promise<{ user: any; error: null } | { user: null; error: string }>;
  signUp: (email: string, password: string, username: string) => Promise<{ user: any; error: null } | { user: null; error: string }>;
  signOut: () => Promise<{ error: string | null }>;
  updateProfile: (updates: Partial<Profile>) => Promise<{ success: boolean; error: string | null }>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

interface AuthProviderProps {
  children: ReactNode;
}

export function AuthProvider({ children }: AuthProviderProps) {
  const [user, setUser] = useState<User | null>(null);
  const [profile, setProfile] = useState<Profile | null>(null);
  const [loading, setLoading] = useState(true);

  // Load user on mount (one-time check)
  useEffect(() => {
    async function loadUser() {
      try {
        const { data: { user } } = await supabase.auth.getUser();
        setUser(user);
        
        if (user) {
          const userProfile = await authService.getUserProfile(user.id);
          setProfile(userProfile);
        }
      } catch (error) {
        console.error('Error loading user:', error);
      } finally {
        setLoading(false);
      }
    }
    
    loadUser();

    // Set up auth listener - KEEP SIMPLE, avoid any async operations in callback
    const { data: { subscription } } = supabase.auth.onAuthStateChange(
      async (event, session) => {
        // NEVER use any async operations in callback that could cause deadlocks
        setUser(session?.user || null);
        
        if (session?.user) {
          // Load profile for authenticated user
          authService.getUserProfile(session.user.id).then(setProfile);
        } else {
          setProfile(null);
        }
        
        setLoading(false);
      }
    );

    return () => subscription.unsubscribe();
  }, []);

  // Auth methods
  async function signIn(email: string, password: string) {
    const result = await authService.signIn({ email, password });
    if (result.user) {
      const userProfile = await authService.getUserProfile(result.user.id);
      setProfile(userProfile);
    }
    return result;
  }

  async function signUp(email: string, password: string, username: string) {
    const result = await authService.signUp({ 
      email, 
      password, 
      confirmPassword: password, 
      username 
    });
    return result;
  }

  async function signOut() {
    const result = await authService.signOut();
    if (!result.error) {
      setUser(null);
      setProfile(null);
    }
    return result;
  }

  async function updateProfile(updates: Partial<Profile>) {
    if (!user) {
      return { success: false, error: 'No user logged in' };
    }
    
    const result = await authService.updateUserProfile(user.id, updates);
    if (result.success && profile) {
      setProfile({ ...profile, ...updates });
    }
    return result;
  }

  const value: AuthContextType = {
    user,
    profile,
    loading,
    signIn,
    signUp,
    signOut,
    updateProfile,
  };

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}