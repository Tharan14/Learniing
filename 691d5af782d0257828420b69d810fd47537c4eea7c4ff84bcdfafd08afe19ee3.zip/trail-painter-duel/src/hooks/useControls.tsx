import { useState, useEffect, useCallback } from 'react';
import { Direction } from '../types';

interface UseKeyboardControlsProps {
  onMove: (direction: Direction) => void;
  enabled?: boolean;
  preventDefault?: boolean;
}

interface UseKeyboardControlsReturn {
  pressedKeys: Set<string>;
  isKeyPressed: (key: string) => boolean;
}

/**
 * Custom hook for handling keyboard controls for game movement
 * Supports both WASD and Arrow keys
 */
export function useKeyboardControls({
  onMove,
  enabled = true,
  preventDefault = true,
}: UseKeyboardControlsProps): UseKeyboardControlsReturn {
  const [pressedKeys, setPressedKeys] = useState<Set<string>>(new Set());
  
  // Key mappings for movement
  const keyMappings: Record<string, Direction> = {
    'ArrowUp': 'up',
    'ArrowDown': 'down',
    'ArrowLeft': 'left',
    'ArrowRight': 'right',
    'KeyW': 'up',
    'KeyS': 'down',
    'KeyA': 'left',
    'KeyD': 'right',
  };
  
  const handleKeyDown = useCallback((event: KeyboardEvent) => {
    if (!enabled) return;
    
    const direction = keyMappings[event.code];
    if (direction) {
      if (preventDefault) {
        event.preventDefault();
      }
      
      // Only trigger move if key wasn't already pressed (prevent key repeat)
      if (!pressedKeys.has(event.code)) {
        onMove(direction);
        setPressedKeys(prev => new Set(prev).add(event.code));
      }
    }
  }, [enabled, preventDefault, onMove, pressedKeys, keyMappings]);
  
  const handleKeyUp = useCallback((event: KeyboardEvent) => {
    if (!enabled) return;
    
    if (keyMappings[event.code]) {
      if (preventDefault) {
        event.preventDefault();
      }
      
      setPressedKeys(prev => {
        const newSet = new Set(prev);
        newSet.delete(event.code);
        return newSet;
      });
    }
  }, [enabled, preventDefault, keyMappings]);
  
  useEffect(() => {
    if (!enabled) {
      setPressedKeys(new Set());
      return;
    }
    
    document.addEventListener('keydown', handleKeyDown);
    document.addEventListener('keyup', handleKeyUp);
    
    return () => {
      document.removeEventListener('keydown', handleKeyDown);
      document.removeEventListener('keyup', handleKeyUp);
    };
  }, [enabled, handleKeyDown, handleKeyUp]);
  
  const isKeyPressed = useCallback((key: string) => {
    return pressedKeys.has(key);
  }, [pressedKeys]);
  
  return {
    pressedKeys,
    isKeyPressed,
  };
}

/**
 * Touch controls hook for mobile devices
 */
interface UseTouchControlsProps {
  onMove: (direction: Direction) => void;
  enabled?: boolean;
}

export function useTouchControls({
  onMove,
  enabled = true,
}: UseTouchControlsProps) {
  const [touchStart, setTouchStart] = useState<{ x: number; y: number } | null>(null);
  
  const handleTouchStart = useCallback((event: TouchEvent) => {
    if (!enabled || event.touches.length === 0) return;
    
    const touch = event.touches[0];
    setTouchStart({ x: touch.clientX, y: touch.clientY });
  }, [enabled]);
  
  const handleTouchEnd = useCallback((event: TouchEvent) => {
    if (!enabled || !touchStart || event.changedTouches.length === 0) return;
    
    const touch = event.changedTouches[0];
    const deltaX = touch.clientX - touchStart.x;
    const deltaY = touch.clientY - touchStart.y;
    
    const minSwipeDistance = 30; // Minimum distance for a swipe
    const absX = Math.abs(deltaX);
    const absY = Math.abs(deltaY);
    
    if (Math.max(absX, absY) < minSwipeDistance) {
      setTouchStart(null);
      return;
    }
    
    // Determine swipe direction
    if (absX > absY) {
      // Horizontal swipe
      onMove(deltaX > 0 ? 'right' : 'left');
    } else {
      // Vertical swipe
      onMove(deltaY > 0 ? 'down' : 'up');
    }
    
    setTouchStart(null);
  }, [enabled, touchStart, onMove]);
  
  const handleTouchCancel = useCallback(() => {
    setTouchStart(null);
  }, []);
  
  useEffect(() => {
    if (!enabled) {
      setTouchStart(null);
      return;
    }
    
    document.addEventListener('touchstart', handleTouchStart);
    document.addEventListener('touchend', handleTouchEnd);
    document.addEventListener('touchcancel', handleTouchCancel);
    
    return () => {
      document.removeEventListener('touchstart', handleTouchStart);
      document.removeEventListener('touchend', handleTouchEnd);
      document.removeEventListener('touchcancel', handleTouchCancel);
    };
  }, [enabled, handleTouchStart, handleTouchEnd, handleTouchCancel]);
  
  return {
    touchStart,
  };
}