import { useState, useEffect, useCallback } from 'react';
import { GameRoom, CreateRoomForm, JoinRoomForm } from '../types';
import { gameRoomService } from '../services/gameService';
import { subscribeToGameRoom, supabase } from '../services/supabase';
import { useAuth } from './useAuth';
import toast from 'react-hot-toast';

interface UseGameRoomReturn {
  // Current room state
  currentRoom: GameRoom | null;
  availableRooms: GameRoom[];
  
  // Room actions
  createRoom: (settings: CreateRoomForm) => Promise<{ success: boolean; room?: GameRoom; error?: string }>;
  joinRoom: (roomCode: string) => Promise<{ success: boolean; room?: GameRoom; error?: string }>;
  leaveRoom: () => Promise<{ success: boolean; error?: string }>;
  refreshAvailableRooms: () => Promise<void>;
  
  // Room status
  roomLoading: boolean;
  roomError: string | null;
  isRoomCreator: boolean;
  playersInRoom: number;
  canStartGame: boolean;
}

export function useGameRoom(): UseGameRoomReturn {
  const { user, profile } = useAuth();
  const [currentRoom, setCurrentRoom] = useState<GameRoom | null>(null);
  const [availableRooms, setAvailableRooms] = useState<GameRoom[]>([]);
  const [roomLoading, setRoomLoading] = useState(false);
  const [roomError, setRoomError] = useState<string | null>(null);
  
  const isRoomCreator = currentRoom?.creatorId === user?.id;
  const playersInRoom = currentRoom?.currentPlayers || 0;
  const canStartGame = playersInRoom >= 2 && isRoomCreator;
  
  // Load available rooms on mount
  useEffect(() => {
    refreshAvailableRooms();
  }, []);
  
  // Set up real-time subscription for current room
  useEffect(() => {
    if (!currentRoom) return;
    
    const subscription = subscribeToGameRoom(currentRoom.id, (payload) => {
      if (payload.eventType === 'UPDATE' && payload.new) {
        const updatedRoom = payload.new as GameRoom;
        setCurrentRoom(updatedRoom);
        
        // Handle room status changes
        if (updatedRoom.status === 'active' && currentRoom.status === 'waiting') {
          toast.success('Game is starting!');
        }
      } else if (payload.eventType === 'DELETE') {
        setCurrentRoom(null);
        toast.error('Room was closed');
      }
    });
    
    return () => {
      if (subscription) {
        supabase.removeChannel(subscription);
      }
    };
  }, [currentRoom]);
  
  // Create a new room
  const createRoom = useCallback(async (settings: CreateRoomForm): Promise<{
    success: boolean;
    room?: GameRoom;
    error?: string;
  }> => {
    if (!user) {
      return { success: false, error: 'Must be logged in to create a room' };
    }
    
    setRoomLoading(true);
    setRoomError(null);
    
    try {
      const roomSettings = {
        isPrivate: settings.isPrivate,
        gameSettings: {
          gridSize: 25,
          roundDuration: settings.roundDuration || 120,
          maxRounds: settings.maxRounds || 3,
          powerUpsEnabled: settings.powerUpsEnabled || false,
        },
      };
      
      const result = await gameRoomService.createRoom(user.id, roomSettings);
      
      if (result.error) {
        setRoomError(result.error);
        toast.error(result.error);
        return { success: false, error: result.error };
      }
      
      setCurrentRoom(result.room);
      toast.success(`Room created! Code: ${result.room!.roomCode}`);
      
      return { success: true, room: result.room! };
    } catch (error: any) {
      const errorMessage = error.message || 'Failed to create room';
      setRoomError(errorMessage);
      toast.error(errorMessage);
      return { success: false, error: errorMessage };
    } finally {
      setRoomLoading(false);
    }
  }, [user]);
  
  // Join an existing room
  const joinRoom = useCallback(async (roomCode: string): Promise<{
    success: boolean;
    room?: GameRoom;
    error?: string;
  }> => {
    if (!user) {
      return { success: false, error: 'Must be logged in to join a room' };
    }
    
    setRoomLoading(true);
    setRoomError(null);
    
    try {
      const result = await gameRoomService.joinRoom(roomCode.toUpperCase(), user.id);
      
      if (result.error) {
        setRoomError(result.error);
        toast.error(result.error);
        return { success: false, error: result.error };
      }
      
      setCurrentRoom(result.room);
      toast.success('Joined room successfully!');
      
      return { success: true, room: result.room! };
    } catch (error: any) {
      const errorMessage = error.message || 'Failed to join room';
      setRoomError(errorMessage);
      toast.error(errorMessage);
      return { success: false, error: errorMessage };
    } finally {
      setRoomLoading(false);
    }
  }, [user]);
  
  // Leave current room
  const leaveRoom = useCallback(async (): Promise<{
    success: boolean;
    error?: string;
  }> => {
    if (!currentRoom || !user) {
      return { success: false, error: 'No room to leave' };
    }
    
    setRoomLoading(true);
    
    try {
      const result = await gameRoomService.leaveRoom(currentRoom.id, user.id);
      
      if (result.error) {
        toast.error(result.error);
        return { success: false, error: result.error };
      }
      
      setCurrentRoom(null);
      toast.success('Left room');
      
      // Refresh available rooms list
      await refreshAvailableRooms();
      
      return { success: true };
    } catch (error: any) {
      const errorMessage = error.message || 'Failed to leave room';
      toast.error(errorMessage);
      return { success: false, error: errorMessage };
    } finally {
      setRoomLoading(false);
    }
  }, [currentRoom, user]);
  
  // Refresh available rooms list
  const refreshAvailableRooms = useCallback(async () => {
    try {
      const rooms = await gameRoomService.getAvailableRooms();
      setAvailableRooms(rooms);
    } catch (error) {
      console.error('Error refreshing available rooms:', error);
    }
  }, []);
  
  // Start a game (only for room creator)
  const startGame = useCallback(async (): Promise<{
    success: boolean;
    gameId?: string;
    error?: string;
  }> => {
    if (!currentRoom || !user || !isRoomCreator || !canStartGame) {
      return { success: false, error: 'Cannot start game' };
    }
    
    setRoomLoading(true);
    
    try {
      // Get all players in the room
      const { data: profiles, error: profilesError } = await supabase
        .from('profiles')
        .select('id')
        .limit(2);
      
      if (profilesError || !profiles || profiles.length < 2) {
        return { success: false, error: 'Not enough players to start game' };
      }
      
      // Create the game
      const result = await gameRoomService.createGame(
        currentRoom.id,
        profiles[0].id,
        profiles[1].id,
        currentRoom.settings.gameSettings
      );
      
      if (result.error) {
        toast.error(result.error);
        return { success: false, error: result.error };
      }
      
      toast.success('Game started!');
      return { success: true, gameId: result.game!.id };
    } catch (error: any) {
      const errorMessage = error.message || 'Failed to start game';
      toast.error(errorMessage);
      return { success: false, error: errorMessage };
    } finally {
      setRoomLoading(false);
    }
  }, [currentRoom, user, isRoomCreator, canStartGame]);
  
  return {
    // Current room state
    currentRoom,
    availableRooms,
    
    // Room actions
    createRoom,
    joinRoom,
    leaveRoom,
    refreshAvailableRooms,
    
    // Room status
    roomLoading,
    roomError,
    isRoomCreator,
    playersInRoom,
    canStartGame,
  };
}