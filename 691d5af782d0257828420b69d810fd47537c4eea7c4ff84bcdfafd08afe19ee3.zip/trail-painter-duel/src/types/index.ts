// Core game types for Trail Painter Duel

export interface Position {
  x: number;
  y: number;
}

export interface Player {
  id: string;
  username: string;
  color: string;
  position: Position;
  territoryCount: number;
  avatar_url?: string;
}

export interface GameCell {
  x: number;
  y: number;
  owner: string | null; // player ID who owns this cell
  lastPainted: number; // timestamp when last painted
}

export interface GameState {
  id: string;
  gameId: string;
  roundNumber: number;
  player1Position: Position;
  player2Position: Position;
  territoryData: Record<string, string>; // "x,y" -> playerId
  roundTimeRemaining: number;
  roundStatus: 'waiting' | 'active' | 'paused' | 'finished';
  player1TerritoryCount: number;
  player2TerritoryCount: number;
  lastUpdated: string;
}

export interface Game {
  id: string;
  roomId: string;
  player1Id: string;
  player2Id: string | null;
  status: 'waiting' | 'active' | 'finished' | 'abandoned';
  currentRound: number;
  maxRounds: number;
  player1Score: number;
  player2Score: number;
  winnerId: string | null;
  gameSettings: GameSettings;
  startedAt: string | null;
  endedAt: string | null;
  createdAt: string;
}

export interface GameRoom {
  id: string;
  roomCode: string;
  creatorId: string;
  status: 'waiting' | 'active' | 'finished';
  maxPlayers: number;
  currentPlayers: number;
  settings: RoomSettings;
  createdAt: string;
  updatedAt: string;
}

export interface Profile {
  id: string;
  username: string;
  avatarUrl: string | null;
  gamesPlayed: number;
  gamesWon: number;
  totalTerritoryPainted: number;
  createdAt: string;
  updatedAt: string;
}

export interface MatchHistory {
  id: string;
  gameId: string;
  playerId: string;
  opponentId: string;
  result: 'win' | 'loss' | 'draw';
  finalScore: number;
  opponentScore: number;
  territoryPainted: number;
  roundsWon: number;
  durationSeconds: number;
  playedAt: string;
}

// Game configuration interfaces
export interface GameSettings {
  gridSize: number;
  roundDuration: number; // seconds
  maxRounds: number;
  powerUpsEnabled: boolean;
}

export interface RoomSettings {
  isPrivate: boolean;
  gameSettings: GameSettings;
}

// Movement and game action types
export type Direction = 'up' | 'down' | 'left' | 'right';

export interface PlayerMove {
  playerId: string;
  direction: Direction;
  timestamp: number;
  newPosition: Position;
}

export interface GameEvent {
  type: 'player_move' | 'territory_painted' | 'round_start' | 'round_end' | 'game_end';
  playerId?: string;
  data: any;
  timestamp: number;
}

// Power-ups (optional feature)
export interface PowerUp {
  id: string;
  type: 'speed_boost' | 'paint_bomb' | 'shield';
  position: Position;
  duration: number; // seconds
  spawnedAt: number;
}

export interface ActivePowerUp {
  playerId: string;
  type: PowerUp['type'];
  expiresAt: number;
}

// UI and component types
export interface GameStats {
  player1Territory: number;
  player2Territory: number;
  totalCells: number;
  timeRemaining: number;
}

export interface LeaderboardEntry {
  rank: number;
  username: string;
  gamesWon: number;
  gamesPlayed: number;
  winRate: number;
  totalTerritoryPainted: number;
}

// Real-time subscription types
export interface RealtimeGameState {
  gameState: GameState;
  players: Player[];
  events: GameEvent[];
}

// Form types for authentication and game setup
export interface LoginForm {
  email: string;
  password: string;
}

export interface SignupForm {
  email: string;
  password: string;
  confirmPassword: string;
  username: string;
}

export interface CreateRoomForm {
  isPrivate: boolean;
  maxRounds: number;
  roundDuration: number;
  powerUpsEnabled: boolean;
}

export interface JoinRoomForm {
  roomCode: string;
}

// Error types
export interface GameError {
  code: string;
  message: string;
  details?: any;
}

// Constants
export const GRID_SIZE = 25;
export const DEFAULT_ROUND_DURATION = 120; // 2 minutes
export const DEFAULT_MAX_ROUNDS = 3;
export const PLAYER_COLORS = {
  PLAYER_1: '#3B82F6', // Electric Blue
  PLAYER_2: '#F59E0B', // Vibrant Orange
  NEUTRAL: '#374151'   // Dark Gray
} as const;

export const GAME_STATUS = {
  WAITING: 'waiting',
  ACTIVE: 'active',
  FINISHED: 'finished',
  ABANDONED: 'abandoned'
} as const;

export const ROUND_STATUS = {
  WAITING: 'waiting',
  ACTIVE: 'active',
  PAUSED: 'paused',
  FINISHED: 'finished'
} as const;