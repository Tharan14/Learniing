import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Settings, Clock, Trophy, Zap, Shield } from 'lucide-react';
import { Button } from '../UI/Button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../UI/Card';
import { Input } from '../UI/Input';
import { CreateRoomForm } from '../../types';
import { cn } from '../../lib/utils';

interface CreateRoomModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (settings: CreateRoomForm) => void;
}

interface ToggleProps {
  enabled: boolean;
  onChange: (enabled: boolean) => void;
  label: string;
  description: string;
  icon?: React.ReactNode;
}

function Toggle({ enabled, onChange, label, description, icon }: ToggleProps) {
  return (
    <div className="flex items-center justify-between p-3 rounded-lg border border-gray-700/50 bg-gray-800/30">
      <div className="flex items-start gap-3">
        {icon && (
          <div className="w-8 h-8 bg-gray-700/50 rounded-full flex items-center justify-center mt-0.5">
            {icon}
          </div>
        )}
        <div>
          <h4 className="text-white font-medium">{label}</h4>
          <p className="text-gray-400 text-sm">{description}</p>
        </div>
      </div>
      <button
        onClick={() => onChange(!enabled)}
        className={cn(
          'relative inline-flex h-6 w-11 items-center rounded-full transition-colors',
          enabled ? 'bg-blue-600' : 'bg-gray-600'
        )}
      >
        <span
          className={cn(
            'inline-block h-4 w-4 transform rounded-full bg-white transition-transform',
            enabled ? 'translate-x-6' : 'translate-x-1'
          )}
        />
      </button>
    </div>
  );
}

export function CreateRoomModal({ isOpen, onClose, onSubmit }: CreateRoomModalProps) {
  const [formData, setFormData] = useState<CreateRoomForm>({
    isPrivate: false,
    maxRounds: 3,
    roundDuration: 120,
    powerUpsEnabled: false,
  });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [submitting, setSubmitting] = useState(false);
  
  const handleInputChange = (field: keyof CreateRoomForm, value: any) => {
    setFormData(prev => ({ ...prev, [field]: value }));
    // Clear error when user makes changes
    if (errors[field]) {
      setErrors(prev => ({ ...prev, [field]: '' }));
    }
  };
  
  const validateForm = () => {
    const newErrors: Record<string, string> = {};
    
    if (formData.maxRounds < 1 || formData.maxRounds > 5) {
      newErrors.maxRounds = 'Max rounds must be between 1 and 5';
    }
    
    if (formData.roundDuration < 60 || formData.roundDuration > 300) {
      newErrors.roundDuration = 'Round duration must be between 60 and 300 seconds';
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };
  
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateForm()) {
      return;
    }
    
    setSubmitting(true);
    try {
      onSubmit(formData);
    } finally {
      setSubmitting(false);
    }
  };
  
  const handleClose = () => {
    if (!submitting) {
      onClose();
      // Reset form after a delay to avoid flash
      setTimeout(() => {
        setFormData({
          isPrivate: false,
          maxRounds: 3,
          roundDuration: 120,
          powerUpsEnabled: false,
        });
        setErrors({});
      }, 300);
    }
  };
  
  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          {/* Backdrop */}
          <motion.div
            className="absolute inset-0 bg-black/80 backdrop-blur-sm"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={handleClose}
          />
          
          {/* Modal */}
          <motion.div
            className="relative w-full max-w-md"
            initial={{ opacity: 0, scale: 0.9, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.9, y: 20 }}
            transition={{ type: 'spring', duration: 0.3 }}
          >
            <Card variant="solid">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div className="w-8 h-8 bg-gradient-to-br from-green-600 to-blue-600 rounded-full flex items-center justify-center">
                      <Settings className="w-4 h-4 text-white" />
                    </div>
                    <CardTitle>Create Game Room</CardTitle>
                  </div>
                  <Button
                    onClick={handleClose}
                    variant="ghost"
                    size="icon"
                    className="h-8 w-8"
                    disabled={submitting}
                  >
                    <X className="h-4 w-4" />
                  </Button>
                </div>
                <CardDescription>
                  Customize your game settings and invite players
                </CardDescription>
              </CardHeader>
              
              <CardContent>
                <form onSubmit={handleSubmit} className="space-y-6">
                  {/* Game Settings */}
                  <div className="space-y-4">
                    <h3 className="text-lg font-semibold text-white flex items-center gap-2">
                      <Trophy className="w-5 h-5 text-yellow-400" />
                      Game Settings
                    </h3>
                    
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <label className="block text-sm font-medium text-gray-300 mb-2">
                          Max Rounds
                        </label>
                        <Input
                          type="number"
                          min={1}
                          max={5}
                          value={formData.maxRounds}
                          onChange={(e) => handleInputChange('maxRounds', parseInt(e.target.value) || 3)}
                          error={errors.maxRounds}
                          disabled={submitting}
                        />
                      </div>
                      
                      <div>
                        <label className="block text-sm font-medium text-gray-300 mb-2">
                          Round Duration (seconds)
                        </label>
                        <Input
                          type="number"
                          min={60}
                          max={300}
                          step={10}
                          value={formData.roundDuration}
                          onChange={(e) => handleInputChange('roundDuration', parseInt(e.target.value) || 120)}
                          error={errors.roundDuration}
                          disabled={submitting}
                        />
                      </div>
                    </div>
                  </div>
                  
                  {/* Room Options */}
                  <div className="space-y-4">
                    <h3 className="text-lg font-semibold text-white flex items-center gap-2">
                      <Settings className="w-5 h-5 text-blue-400" />
                      Room Options
                    </h3>
                    
                    <div className="space-y-3">
                      <Toggle
                        enabled={formData.isPrivate}
                        onChange={(enabled) => handleInputChange('isPrivate', enabled)}
                        label="Private Room"
                        description="Only players with the room code can join"
                        icon={<Shield className="w-4 h-4 text-gray-400" />}
                      />
                      
                      <Toggle
                        enabled={formData.powerUpsEnabled}
                        onChange={(enabled) => handleInputChange('powerUpsEnabled', enabled)}
                        label="Power-ups (Coming Soon)"
                        description="Enable special abilities during gameplay"
                        icon={<Zap className="w-4 h-4 text-gray-400" />}
                      />
                    </div>
                  </div>
                  
                  {/* Preview */}
                  <div className="bg-gray-800/50 rounded-lg p-4 border border-gray-700/50">
                    <h4 className="text-white font-medium mb-2">Game Preview</h4>
                    <div className="text-sm text-gray-400 space-y-1">
                      <p>
                        • {formData.maxRounds} round{formData.maxRounds !== 1 ? 's' : ''} to win
                      </p>
                      <p>
                        • {Math.floor(formData.roundDuration / 60)}:{(formData.roundDuration % 60).toString().padStart(2, '0')} per round
                      </p>
                      <p>
                        • {formData.isPrivate ? 'Private' : 'Public'} room
                      </p>
                      {formData.powerUpsEnabled && (
                        <p>• Power-ups enabled</p>
                      )}
                    </div>
                  </div>
                  
                  {/* Actions */}
                  <div className="flex gap-3">
                    <Button
                      type="button"
                      onClick={handleClose}
                      variant="outline"
                      className="flex-1"
                      disabled={submitting}
                    >
                      Cancel
                    </Button>
                    <Button
                      type="submit"
                      loading={submitting}
                      className="flex-1"
                      variant="success"
                    >
                      Create Room
                    </Button>
                  </div>
                </form>
              </CardContent>
            </Card>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
}