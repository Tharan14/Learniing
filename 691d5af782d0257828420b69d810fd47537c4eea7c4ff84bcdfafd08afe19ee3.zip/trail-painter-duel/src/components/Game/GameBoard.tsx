import React, { useMemo } from 'react';
import { motion } from 'framer-motion';
import { Player, GameCell, GRID_SIZE, PLAYER_COLORS } from '../../types';
import { cn } from '../../lib/utils';

interface GameBoardProps {
  players: Player[];
  territoryData: Record<string, string>;
  gridSize?: number;
  className?: string;
}

interface CellProps {
  x: number;
  y: number;
  owner: string | null;
  hasPlayer: boolean;
  playerColor?: string;
  isPlayer1: boolean;
  isPlayer2: boolean;
}

function GameCell({ x, y, owner, hasPlayer, playerColor, isPlayer1, isPlayer2 }: CellProps) {
  const getCellColor = () => {
    if (hasPlayer) {
      return playerColor || PLAYER_COLORS.NEUTRAL;
    }
    if (owner) {
      // Get owner color from player colors (simplified)
      return isPlayer1 ? PLAYER_COLORS.PLAYER_1 : PLAYER_COLORS.PLAYER_2;
    }
    return PLAYER_COLORS.NEUTRAL;
  };
  
  const cellColor = getCellColor();
  const isPainted = !!owner;
  
  return (
    <motion.div
      className={cn(
        'aspect-square border border-gray-700/30 relative overflow-hidden',
        hasPlayer && 'ring-2 ring-white/60 ring-offset-1 ring-offset-gray-900'
      )}
      style={{
        backgroundColor: cellColor,
        opacity: isPainted ? 0.8 : 0.3,
      }}
      initial={{ scale: hasPlayer ? 0.9 : 1 }}
      animate={{ 
        scale: hasPlayer ? 1.1 : 1,
        backgroundColor: cellColor,
      }}
      transition={{ 
        duration: 0.2,
        ease: 'easeOut'
      }}
    >
      {hasPlayer && (
        <motion.div
          className="absolute inset-1 rounded-full bg-white/90 shadow-lg flex items-center justify-center"
          initial={{ scale: 0, rotate: -180 }}
          animate={{ scale: 1, rotate: 0 }}
          transition={{ 
            duration: 0.3,
            ease: 'backOut'
          }}
        >
          <div 
            className="w-3 h-3 rounded-full shadow-inner"
            style={{ backgroundColor: playerColor }}
          />
        </motion.div>
      )}
      
      {isPainted && !hasPlayer && (
        <motion.div
          className="absolute inset-0 bg-gradient-to-br from-transparent via-white/10 to-transparent"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.5 }}
        />
      )}
    </motion.div>
  );
}

function PlayerAvatar({ player, isCurrentPlayer }: { player: Player; isCurrentPlayer: boolean }) {
  return (
    <motion.div
      className={cn(
        'absolute z-10 pointer-events-none',
        isCurrentPlayer && 'ring-2 ring-white/60'
      )}
      style={{
        left: `${(player.position.x / GRID_SIZE) * 100}%`,
        top: `${(player.position.y / GRID_SIZE) * 100}%`,
        transform: 'translate(-50%, -50%)',
      }}
      initial={{ scale: 0 }}
      animate={{ scale: 1 }}
      transition={{ 
        type: 'spring',
        stiffness: 300,
        damping: 25
      }}
    >
      <div 
        className="w-8 h-8 rounded-full border-2 border-white/80 shadow-lg flex items-center justify-center text-white font-bold text-sm"
        style={{ backgroundColor: player.color }}
      >
        {player.username.charAt(0).toUpperCase()}
      </div>
    </motion.div>
  );
}

export function GameBoard({ players, territoryData, gridSize = GRID_SIZE, className }: GameBoardProps) {
  // Create grid cells
  const gridCells = useMemo(() => {
    const cells = [];
    for (let y = 0; y < gridSize; y++) {
      for (let x = 0; x < gridSize; x++) {
        cells.push({ x, y });
      }
    }
    return cells;
  }, [gridSize]);
  
  // Get player positions for quick lookup
  const playerPositions = useMemo(() => {
    const positions = new Map<string, Player>();
    players.forEach(player => {
      const key = `${player.position.x},${player.position.y}`;
      positions.set(key, player);
    });
    return positions;
  }, [players]);
  
  return (
    <div className={cn('relative', className)}>
      {/* Game Grid */}
      <div 
        className="grid gap-0 border-2 border-gray-600 rounded-lg overflow-hidden bg-gray-900 shadow-2xl"
        style={{
          gridTemplateColumns: `repeat(${gridSize}, minmax(0, 1fr))`,
          aspectRatio: '1',
        }}
      >
        {gridCells.map(({ x, y }) => {
          const positionKey = `${x},${y}`;
          const owner = territoryData[positionKey];
          const playerAtPosition = playerPositions.get(positionKey);
          const hasPlayer = !!playerAtPosition;
          
          // Determine if this cell belongs to player 1 or 2
          const isPlayer1Territory = owner === players[0]?.id;
          const isPlayer2Territory = owner === players[1]?.id;
          
          return (
            <GameCell
              key={positionKey}
              x={x}
              y={y}
              owner={owner}
              hasPlayer={hasPlayer}
              playerColor={playerAtPosition?.color}
              isPlayer1={isPlayer1Territory}
              isPlayer2={isPlayer2Territory}
            />
          );
        })}
      </div>
      
      {/* Player Avatars (positioned absolutely over the grid) */}
      {players.map((player, index) => (
        <PlayerAvatar
          key={player.id}
          player={player}
          isCurrentPlayer={index === 0} // Could be enhanced to show current turn
        />
      ))}
      
      {/* Grid Overlay for Better Visibility */}
      <div 
        className="absolute inset-0 pointer-events-none"
        style={{
          backgroundImage: `
            linear-gradient(to right, rgba(255,255,255,0.1) 1px, transparent 1px),
            linear-gradient(to bottom, rgba(255,255,255,0.1) 1px, transparent 1px)
          `,
          backgroundSize: `${100/gridSize}% ${100/gridSize}%`,
        }}
      />
    </div>
  );
}