import React from 'react';
import { motion } from 'framer-motion';
import { Clock, Trophy, Target, Zap, Users } from 'lucide-react';
import { Player } from '../../types';
import { gameUtils } from '../../game/gameLogic';
import { cn } from '../../lib/utils';

interface GameHUDProps {
  players: Player[];
  timeRemaining: number;
  currentRound: number;
  maxRounds: number;
  player1Score: number;
  player2Score: number;
  myPlayerId: string | null;
  myTerritoryPercentage: number;
  opponentTerritoryPercentage: number;
  isGameActive: boolean;
  className?: string;
}

interface PlayerStatsProps {
  player: Player;
  score: number;
  territoryPercentage: number;
  isCurrentPlayer: boolean;
  isWinning: boolean;
}

function PlayerStats({ player, score, territoryPercentage, isCurrentPlayer, isWinning }: PlayerStatsProps) {
  return (
    <motion.div
      className={cn(
        'bg-gray-800/80 backdrop-blur-sm rounded-lg p-3 border',
        isCurrentPlayer 
          ? 'border-white/40 ring-2 ring-blue-400/40' 
          : 'border-gray-700/50',
        isWinning && 'bg-gradient-to-br from-green-900/30 to-gray-800/80'
      )}
      animate={{
        scale: isWinning ? 1.02 : 1,
      }}
      transition={{ duration: 0.3 }}
    >
      <div className="flex items-center gap-2 mb-2">
        <div 
          className="w-4 h-4 rounded-full border-2 border-white/60"
          style={{ backgroundColor: player.color }}
        />
        <span className="text-white font-semibold text-sm truncate">
          {player.username}
        </span>
        {isCurrentPlayer && (
          <span className="text-xs text-blue-400 font-medium">(You)</span>
        )}
      </div>
      
      <div className="space-y-1 text-xs">
        <div className="flex items-center justify-between">
          <span className="text-gray-400 flex items-center gap-1">
            <Trophy className="w-3 h-3" />
            Rounds
          </span>
          <span className="text-white font-bold">{score}</span>
        </div>
        
        <div className="flex items-center justify-between">
          <span className="text-gray-400 flex items-center gap-1">
            <Target className="w-3 h-3" />
            Territory
          </span>
          <span className="text-white font-bold">
            {territoryPercentage.toFixed(1)}%
          </span>
        </div>
        
        {/* Territory Progress Bar */}
        <div className="w-full bg-gray-700 rounded-full h-1.5 overflow-hidden">
          <motion.div
            className="h-full rounded-full"
            style={{ backgroundColor: player.color }}
            initial={{ width: 0 }}
            animate={{ width: `${territoryPercentage}%` }}
            transition={{ duration: 0.5, ease: 'easeOut' }}
          />
        </div>
      </div>
    </motion.div>
  );
}

function Timer({ timeRemaining, isGameActive }: { timeRemaining: number; isGameActive: boolean }) {
  const minutes = Math.floor(timeRemaining / 60);
  const seconds = timeRemaining % 60;
  const isLowTime = timeRemaining <= 30;
  
  return (
    <motion.div
      className={cn(
        'bg-gray-800/90 backdrop-blur-sm rounded-lg p-3 border',
        isLowTime 
          ? 'border-red-500/60 bg-gradient-to-br from-red-900/30 to-gray-800/90' 
          : 'border-gray-700/50'
      )}
      animate={{
        scale: isLowTime ? [1, 1.05, 1] : 1,
      }}
      transition={{
        duration: 1,
        repeat: isLowTime ? Infinity : 0,
        ease: 'easeInOut'
      }}
    >
      <div className="flex items-center justify-center gap-2">
        <Clock className={cn(
          'w-5 h-5',
          isLowTime ? 'text-red-400' : 'text-blue-400'
        )} />
        <span className={cn(
          'font-mono font-bold text-lg',
          isLowTime ? 'text-red-400' : 'text-white'
        )}>
          {gameUtils.formatTime(timeRemaining)}
        </span>
      </div>
      
      <div className="text-center mt-1">
        <span className="text-xs text-gray-400">
          {isGameActive ? 'Time Left' : 'Round Ended'}
        </span>
      </div>
    </motion.div>
  );
}

function RoundCounter({ currentRound, maxRounds }: { currentRound: number; maxRounds: number }) {
  return (
    <div className="bg-gray-800/80 backdrop-blur-sm rounded-lg p-3 border border-gray-700/50">
      <div className="flex items-center justify-center gap-2">
        <Zap className="w-4 h-4 text-yellow-400" />
        <span className="text-white font-semibold">
          Round {currentRound} of {maxRounds}
        </span>
      </div>
      
      {/* Round Progress */}
      <div className="flex gap-1 mt-2">
        {Array.from({ length: maxRounds }, (_, i) => (
          <div
            key={i}
            className={cn(
              'h-1.5 rounded-full flex-1',
              i < currentRound 
                ? 'bg-yellow-400' 
                : 'bg-gray-700'
            )}
          />
        ))}
      </div>
    </div>
  );
}

function ControlsHint() {
  return (
    <motion.div
      className="bg-gray-800/60 backdrop-blur-sm rounded-lg p-2 border border-gray-700/30"
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 1, duration: 0.5 }}
    >
      <div className="text-center">
        <span className="text-xs text-gray-400">Controls:</span>
        <div className="flex justify-center gap-2 mt-1 text-xs">
          <span className="text-white">WASD</span>
          <span className="text-gray-500">or</span>
          <span className="text-white">Arrow Keys</span>
        </div>
      </div>
    </motion.div>
  );
}

export function GameHUD({
  players,
  timeRemaining,
  currentRound,
  maxRounds,
  player1Score,
  player2Score,
  myPlayerId,
  myTerritoryPercentage,
  opponentTerritoryPercentage,
  isGameActive,
  className
}: GameHUDProps) {
  const player1 = players[0];
  const player2 = players[1];
  
  const myScore = player1?.id === myPlayerId ? player1Score : player2Score;
  const opponentScore = player1?.id === myPlayerId ? player2Score : player1Score;
  
  const isPlayer1Winning = myTerritoryPercentage > opponentTerritoryPercentage;
  const isPlayer2Winning = opponentTerritoryPercentage > myTerritoryPercentage;
  
  return (
    <div className={cn('space-y-3', className)}>
      {/* Top Row: Timer and Round */}
      <div className="flex gap-3">
        <div className="flex-1">
          <Timer timeRemaining={timeRemaining} isGameActive={isGameActive} />
        </div>
        <div className="flex-1">
          <RoundCounter currentRound={currentRound} maxRounds={maxRounds} />
        </div>
      </div>
      
      {/* Player Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
        {player1 && (
          <PlayerStats
            player={player1}
            score={player1Score}
            territoryPercentage={player1.id === myPlayerId ? myTerritoryPercentage : opponentTerritoryPercentage}
            isCurrentPlayer={player1.id === myPlayerId}
            isWinning={player1.id === myPlayerId ? isPlayer1Winning : isPlayer2Winning}
          />
        )}
        
        {player2 && (
          <PlayerStats
            player={player2}
            score={player2Score}
            territoryPercentage={player2.id === myPlayerId ? myTerritoryPercentage : opponentTerritoryPercentage}
            isCurrentPlayer={player2.id === myPlayerId}
            isWinning={player2.id === myPlayerId ? isPlayer1Winning : isPlayer2Winning}
          />
        )}
      </div>
      
      {/* Controls Hint */}
      <ControlsHint />
    </div>
  );
}