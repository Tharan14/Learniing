import React from 'react';
import { motion } from 'framer-motion';
import { Trophy, Target, Clock, Medal, Crown, Star } from 'lucide-react';
import { Button } from '../UI/Button';
import { cn } from '../../lib/utils';
import { gameUtils } from '../../game/gameLogic';

interface GameResultsProps {
  winner: {
    id: string;
    username: string;
    color: string;
  } | null;
  finalScores: {
    player1: { username: string; score: number; territory: number };
    player2: { username: string; score: number; territory: number };
  };
  gameDuration: number;
  isPlayer: boolean;
  myPlayerId: string | null;
  onPlayAgain: () => void;
  onGoHome: () => void;
  className?: string;
}

interface StatCardProps {
  icon: React.ReactNode;
  label: string;
  value: string | number;
  highlight?: boolean;
}

function StatCard({ icon, label, value, highlight = false }: StatCardProps) {
  return (
    <div className={cn(
      'bg-gray-800/60 backdrop-blur-sm rounded-lg p-3 border',
      highlight ? 'border-yellow-400/40 bg-gradient-to-br from-yellow-900/20 to-gray-800/60' : 'border-gray-700/50'
    )}>
      <div className="flex items-center gap-2 mb-1">
        <div className={cn(
          'p-1.5 rounded-full',
          highlight ? 'bg-yellow-400/20 text-yellow-400' : 'bg-gray-700/50 text-gray-400'
        )}>
          {icon}
        </div>
        <span className="text-xs text-gray-400 font-medium">{label}</span>
      </div>
      <div className={cn(
        'text-lg font-bold',
        highlight ? 'text-yellow-400' : 'text-white'
      )}>
        {value}
      </div>
    </div>
  );
}

function PlayerResultCard({
  player,
  isWinner,
  isCurrentPlayer,
  rank
}: {
  player: { username: string; score: number; territory: number };
  isWinner: boolean;
  isCurrentPlayer: boolean;
  rank: number;
}) {
  return (
    <motion.div
      className={cn(
        'bg-gray-800/80 backdrop-blur-sm rounded-xl p-4 border-2',
        isWinner 
          ? 'border-yellow-400/60 bg-gradient-to-br from-yellow-900/30 to-gray-800/80'
          : 'border-gray-700/50',
        isCurrentPlayer && 'ring-2 ring-blue-400/40'
      )}
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.2 * rank, duration: 0.5 }}
    >
      <div className="flex items-center gap-3 mb-3">
        <div className={cn(
          'w-10 h-10 rounded-full flex items-center justify-center text-white font-bold border-2',
          isWinner 
            ? 'bg-yellow-500 border-yellow-400' 
            : 'bg-gray-600 border-gray-500'
        )}>
          {isWinner ? (
            <Crown className="w-5 h-5" />
          ) : (
            <span>#{rank}</span>
          )}
        </div>
        
        <div className="flex-1">
          <div className="flex items-center gap-2">
            <h3 className="text-white font-bold">{player.username}</h3>
            {isCurrentPlayer && (
              <span className="text-xs text-blue-400 font-medium px-2 py-1 bg-blue-900/30 rounded">
                You
              </span>
            )}
          </div>
          {isWinner && (
            <p className="text-yellow-400 text-sm font-medium">Winner!</p>
          )}
        </div>
        
        {isWinner && (
          <motion.div
            animate={{ rotate: [0, -10, 10, 0] }}
            transition={{ duration: 2, repeat: Infinity }}
          >
            <Trophy className="w-6 h-6 text-yellow-400" />
          </motion.div>
        )}
      </div>
      
      <div className="grid grid-cols-2 gap-2">
        <StatCard
          icon={<Medal className="w-4 h-4" />}
          label="Rounds Won"
          value={player.score}
          highlight={isWinner}
        />
        <StatCard
          icon={<Target className="w-4 h-4" />}
          label="Territory"
          value={`${player.territory.toFixed(1)}%`}
          highlight={isWinner}
        />
      </div>
    </motion.div>
  );
}

export function GameResults({
  winner,
  finalScores,
  gameDuration,
  isPlayer,
  myPlayerId,
  onPlayAgain,
  onGoHome,
  className
}: GameResultsProps) {
  const isDraw = !winner;
  const didIWin = winner?.id === myPlayerId;
  
  const player1IsWinner = winner?.id && finalScores.player1.username === winner.username;
  const player2IsWinner = winner?.id && finalScores.player2.username === winner.username;
  
  return (
    <div className={cn('space-y-6', className)}>
      {/* Header */}
      <motion.div
        className="text-center"
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.5 }}
      >
        <div className="flex justify-center mb-4">
          {isDraw ? (
            <div className="w-16 h-16 bg-gray-600 rounded-full flex items-center justify-center border-4 border-gray-500">
              <Star className="w-8 h-8 text-gray-300" />
            </div>
          ) : (
            <motion.div
              className="w-16 h-16 bg-gradient-to-br from-yellow-400 to-yellow-600 rounded-full flex items-center justify-center border-4 border-yellow-300"
              animate={{ 
                rotate: [0, -5, 5, 0],
                scale: [1, 1.05, 1]
              }}
              transition={{ 
                duration: 2,
                repeat: Infinity,
                ease: 'easeInOut'
              }}
            >
              <Crown className="w-8 h-8 text-white" />
            </motion.div>
          )}
        </div>
        
        <h1 className="text-3xl font-bold text-white mb-2">
          {isDraw 
            ? "It's a Draw!" 
            : isPlayer && didIWin 
              ? "Congratulations!" 
              : isPlayer && !didIWin
                ? "Better Luck Next Time!"
                : "Game Over"
          }
        </h1>
        
        {!isDraw && (
          <p className="text-xl text-gray-300">
            <span className="text-yellow-400 font-semibold">{winner.username}</span> wins!
          </p>
        )}
      </motion.div>
      
      {/* Player Results */}
      <div className="space-y-3">
        <PlayerResultCard
          player={finalScores.player1}
          isWinner={!!player1IsWinner}
          isCurrentPlayer={isPlayer && myPlayerId === winner?.id && player1IsWinner}
          rank={1}
        />
        
        <PlayerResultCard
          player={finalScores.player2}
          isWinner={!!player2IsWinner}
          isCurrentPlayer={isPlayer && myPlayerId === winner?.id && player2IsWinner}
          rank={2}
        />
      </div>
      
      {/* Game Stats */}
      <motion.div
        className="bg-gray-800/60 backdrop-blur-sm rounded-xl p-4 border border-gray-700/50"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.6, duration: 0.5 }}
      >
        <h3 className="text-white font-semibold mb-3 flex items-center gap-2">
          <Clock className="w-4 h-4" />
          Game Statistics
        </h3>
        
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          <StatCard
            icon={<Clock className="w-4 h-4" />}
            label="Duration"
            value={gameUtils.formatTime(gameDuration)}
          />
          
          <StatCard
            icon={<Target className="w-4 h-4" />}
            label="Total Territory"
            value={`${(finalScores.player1.territory + finalScores.player2.territory).toFixed(1)}%`}
          />
          
          <StatCard
            icon={<Medal className="w-4 h-4" />}
            label="Total Rounds"
            value={finalScores.player1.score + finalScores.player2.score}
          />
        </div>
      </motion.div>
      
      {/* Actions */}
      <motion.div
        className="flex gap-3"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.8, duration: 0.5 }}
      >
        <Button
          onClick={onPlayAgain}
          className="flex-1 bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700"
          size="lg"
        >
          Play Again
        </Button>
        
        <Button
          onClick={onGoHome}
          variant="outline"
          className="flex-1 border-gray-600 text-gray-300 hover:bg-gray-800"
          size="lg"
        >
          Home
        </Button>
      </motion.div>
    </div>
  );
}