import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Gamepad2, Trophy, Users, Target, Clock, Settings } from 'lucide-react';
import { Button } from '../components/UI/Button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../components/UI/Card';
import { useAuth } from '../hooks/useAuth';
import { authService } from '../services/authService';
import { cn } from '../lib/utils';

interface HomePageProps {
  onStartGame: () => void;
  onViewLeaderboard: () => void;
  onLogout: () => void;
}

interface StatCardProps {
  icon: React.ReactNode;
  label: string;
  value: string | number;
  description: string;
}

function StatCard({ icon, label, value, description }: StatCardProps) {
  return (
    <Card variant="glass">
      <CardContent className="text-center">
        <div className="w-12 h-12 mx-auto mb-3 bg-gradient-to-br from-blue-600 to-purple-600 rounded-full flex items-center justify-center">
          {icon}
        </div>
        <h3 className="text-2xl font-bold text-white mb-1">{value}</h3>
        <p className="text-sm font-medium text-gray-300 mb-1">{label}</p>
        <p className="text-xs text-gray-400">{description}</p>
      </CardContent>
    </Card>
  );
}

function FeatureCard({ 
  icon, 
  title, 
  description 
}: { 
  icon: React.ReactNode; 
  title: string; 
  description: string;
}) {
  return (
    <motion.div
      whileHover={{ scale: 1.02 }}
      transition={{ type: 'spring', stiffness: 300 }}
    >
      <Card variant="gradient" className="h-full">
        <CardContent className="text-center">
          <div className="w-12 h-12 mx-auto mb-3 bg-gradient-to-br from-green-600 to-blue-600 rounded-full flex items-center justify-center">
            {icon}
          </div>
          <h3 className="text-lg font-semibold text-white mb-2">{title}</h3>
          <p className="text-gray-400 text-sm">{description}</p>
        </CardContent>
      </Card>
    </motion.div>
  );
}

export function HomePage({ onStartGame, onViewLeaderboard, onLogout }: HomePageProps) {
  const { user, profile } = useAuth();
  const [leaderboard, setLeaderboard] = useState<any[]>([]);
  const [loadingLeaderboard, setLoadingLeaderboard] = useState(false);
  
  // Load leaderboard on component mount
  React.useEffect(() => {
    const loadLeaderboard = async () => {
      setLoadingLeaderboard(true);
      try {
        const data = await authService.getLeaderboard(5);
        setLeaderboard(data);
      } catch (error) {
        console.error('Error loading leaderboard:', error);
      } finally {
        setLoadingLeaderboard(false);
      }
    };
    
    loadLeaderboard();
  }, []);
  
  const winRate = profile?.gamesPlayed 
    ? Math.round((profile.gamesWon / profile.gamesPlayed) * 100)
    : 0;
  
  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-blue-900 to-purple-900 p-4">
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-5">
        <div className="absolute inset-0" style={{
          backgroundImage: `
            radial-gradient(circle at 20% 20%, rgba(59, 130, 246, 0.3) 0%, transparent 50%),
            radial-gradient(circle at 80% 80%, rgba(147, 51, 234, 0.3) 0%, transparent 50%),
            radial-gradient(circle at 50% 50%, rgba(245, 158, 11, 0.2) 0%, transparent 50%)
          `
        }} />
      </div>
      
      <div className="relative max-w-6xl mx-auto py-8">
        {/* Header */}
        <motion.div
          className="text-center mb-12"
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
        >
          <div className="flex items-center justify-center mb-6">
            <div className="w-16 h-16 bg-gradient-to-br from-blue-600 to-purple-600 rounded-full flex items-center justify-center mr-4">
              <Gamepad2 className="w-8 h-8 text-white" />
            </div>
            <div className="text-left">
              <h1 className="text-4xl md:text-5xl font-bold text-white mb-2">
                Trail Painter Duel
              </h1>
              <p className="text-gray-400 text-lg">
                Compete in real-time territory control battles
              </p>
            </div>
          </div>
          
          {user && profile && (
            <motion.div
              className="inline-flex items-center gap-2 bg-gray-800/60 backdrop-blur-sm rounded-full px-4 py-2 border border-gray-700/50"
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: 0.2 }}
            >
              <div className="w-8 h-8 bg-gradient-to-br from-green-600 to-blue-600 rounded-full flex items-center justify-center">
                <span className="text-white font-bold text-sm">
                  {profile.username.charAt(0).toUpperCase()}
                </span>
              </div>
              <span className="text-white font-medium">Welcome back, {profile.username}!</span>
            </motion.div>
          )}
        </motion.div>
        
        {/* Main Actions */}
        <motion.div
          className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-12"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
        >
          <Card variant="highlight" size="lg">
            <CardContent className="text-center">
              <div className="w-16 h-16 bg-gradient-to-br from-green-600 to-emerald-600 rounded-full flex items-center justify-center mx-auto mb-4">
                <Gamepad2 className="w-8 h-8 text-white" />
              </div>
              <h2 className="text-2xl font-bold text-white mb-2">Start Playing</h2>
              <p className="text-gray-400 mb-6">
                Jump into multiplayer battles and paint your way to victory
              </p>
              <Button
                onClick={onStartGame}
                size="xl"
                className="w-full bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700"
              >
                Play Now
              </Button>
            </CardContent>
          </Card>
          
          <Card variant="default" size="lg">
            <CardContent className="text-center">
              <div className="w-16 h-16 bg-gradient-to-br from-yellow-600 to-orange-600 rounded-full flex items-center justify-center mx-auto mb-4">
                <Trophy className="w-8 h-8 text-white" />
              </div>
              <h2 className="text-2xl font-bold text-white mb-2">Leaderboard</h2>
              <p className="text-gray-400 mb-6">
                See how you rank against other players worldwide
              </p>
              <Button
                onClick={onViewLeaderboard}
                size="xl"
                variant="warning"
                className="w-full"
              >
                View Rankings
              </Button>
            </CardContent>
          </Card>
        </motion.div>
        
        {/* Player Stats */}
        {profile && (
          <motion.div
            className="mb-12"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4 }}
          >
            <h2 className="text-2xl font-bold text-white mb-6 text-center">Your Stats</h2>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <StatCard
                icon={<Trophy className="w-6 h-6 text-white" />}
                label="Games Won"
                value={profile.gamesWon}
                description="Total victories"
              />
              <StatCard
                icon={<Users className="w-6 h-6 text-white" />}
                label="Games Played"
                value={profile.gamesPlayed}
                description="Total matches"
              />
              <StatCard
                icon={<Target className="w-6 h-6 text-white" />}
                label="Win Rate"
                value={`${winRate}%`}
                description="Success percentage"
              />
              <StatCard
                icon={<Settings className="w-6 h-6 text-white" />}
                label="Territory Painted"
                value={Math.floor(profile.totalTerritoryPainted / 100) || 0}
                description="Total cells painted"
              />
            </div>
          </motion.div>
        )}
        
        {/* Quick Leaderboard Preview */}
        <motion.div
          className="mb-12"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
        >
          <Card variant="glass">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Trophy className="w-5 h-5 text-yellow-400" />
                Top Players
              </CardTitle>
              <CardDescription>
                See who's dominating the battlefield
              </CardDescription>
            </CardHeader>
            <CardContent>
              {loadingLeaderboard ? (
                <div className="space-y-2">
                  {Array.from({ length: 3 }, (_, i) => (
                    <div key={i} className="animate-pulse flex items-center gap-3">
                      <div className="w-8 h-8 bg-gray-700 rounded-full" />
                      <div className="flex-1 h-4 bg-gray-700 rounded" />
                      <div className="w-16 h-4 bg-gray-700 rounded" />
                    </div>
                  ))}
                </div>
              ) : leaderboard.length > 0 ? (
                <div className="space-y-2">
                  {leaderboard.slice(0, 5).map((player, index) => (
                    <div key={player.username} className="flex items-center gap-3 p-2 rounded-lg hover:bg-gray-800/30">
                      <div className={cn(
                        'w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold',
                        index === 0 ? 'bg-yellow-500 text-white' :
                        index === 1 ? 'bg-gray-400 text-white' :
                        index === 2 ? 'bg-orange-500 text-white' :
                        'bg-gray-700 text-gray-300'
                      )}>
                        {index + 1}
                      </div>
                      <span className="flex-1 text-white font-medium">{player.username}</span>
                      <span className="text-sm text-gray-400">
                        {player.gamesWon} wins ({player.winRate}%)
                      </span>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-gray-400 text-center py-4">
                  No leaderboard data available
                </p>
              )}
              
              <div className="mt-4">
                <Button onClick={onViewLeaderboard} variant="outline" className="w-full">
                  View Full Leaderboard
                </Button>
              </div>
            </CardContent>
          </Card>
        </motion.div>
        
        {/* How to Play */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.6 }}
        >
          <h2 className="text-2xl font-bold text-white mb-6 text-center">How to Play</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <FeatureCard
              icon={<Target className="w-6 h-6 text-white" />}
              title="Paint Territory"
              description="Move around the grid to paint cells with your color and claim territory"
            />
            <FeatureCard
              icon={<Users className="w-6 h-6 text-white" />}
              title="Compete in Real-Time"
              description="Face off against other players in fast-paced 2-minute rounds"
            />
            <FeatureCard
              icon={<Trophy className="w-6 h-6 text-white" />}
              title="Win by Territory"
              description="Control the most territory when time runs out to win the round"
            />
          </div>
        </motion.div>
        
        {/* Footer */}
        <motion.div
          className="mt-12 text-center"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.8 }}
        >
          <div className="flex justify-center gap-4">
            <Button onClick={onLogout} variant="ghost" size="sm">
              Sign Out
            </Button>
          </div>
        </motion.div>
      </div>
    </div>
  );
}