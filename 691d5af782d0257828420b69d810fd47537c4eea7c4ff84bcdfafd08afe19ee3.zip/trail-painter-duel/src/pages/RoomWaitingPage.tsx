import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Copy, Users, Settings, Play, ArrowLeft, Crown, Clock, Trophy } from 'lucide-react';
import { Button } from '../components/UI/Button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../components/UI/Card';
import { GameRoom } from '../types';
import { useAuth } from '../hooks/useAuth';
import { gameService } from '../services/gameService';
import { supabase } from '../services/supabase';
import { copyToClipboard } from '../utils';
import { cn } from '../lib/utils';
import toast from 'react-hot-toast';

interface RoomWaitingPageProps {
  room: GameRoom;
  onStartGame: (gameId: string) => void;
  onLeaveRoom: () => void;
  onGoBack: () => void;
}

interface PlayerCardProps {
  username: string;
  isCreator: boolean;
  isYou: boolean;
}

function PlayerCard({ username, isCreator, isYou }: PlayerCardProps) {
  return (
    <motion.div
      className={cn(
        'flex items-center gap-3 p-3 rounded-lg border',
        isYou 
          ? 'border-blue-500/40 bg-blue-900/20' 
          : 'border-gray-700/50 bg-gray-800/30'
      )}
      initial={{ opacity: 0, x: -20 }}
      animate={{ opacity: 1, x: 0 }}
      transition={{ duration: 0.3 }}
    >
      <div className={cn(
        'w-10 h-10 rounded-full flex items-center justify-center font-bold text-white',
        isYou ? 'bg-blue-600' : 'bg-gray-600'
      )}>
        {username.charAt(0).toUpperCase()}
      </div>
      
      <div className="flex-1">
        <div className="flex items-center gap-2">
          <span className="text-white font-medium">{username}</span>
          {isCreator && (
            <Crown className="w-4 h-4 text-yellow-400" title="Room Creator" />
          )}
          {isYou && (
            <span className="text-xs text-blue-400 bg-blue-900/30 px-2 py-1 rounded">
              You
            </span>
          )}
        </div>
        <p className="text-xs text-gray-400">
          {isCreator ? 'Room Creator' : 'Player'}
        </p>
      </div>
      
      <div className="w-3 h-3 bg-green-400 rounded-full animate-pulse" title="Online" />
    </motion.div>
  );
}

function EmptyPlayerSlot() {
  return (
    <motion.div
      className="flex items-center gap-3 p-3 rounded-lg border border-dashed border-gray-600 bg-gray-800/20"
      initial={{ opacity: 0, x: -20 }}
      animate={{ opacity: 1, x: 0 }}
      transition={{ duration: 0.3, delay: 0.1 }}
    >
      <div className="w-10 h-10 rounded-full border-2 border-dashed border-gray-600 flex items-center justify-center">
        <Users className="w-5 h-5 text-gray-600" />
      </div>
      
      <div className="flex-1">
        <span className="text-gray-500 font-medium">Waiting for player...</span>
        <p className="text-xs text-gray-600">Room is public, anyone can join</p>
      </div>
    </motion.div>
  );
}

export function RoomWaitingPage({ room, onStartGame, onLeaveRoom, onGoBack }: RoomWaitingPageProps) {
  const { user, profile } = useAuth();
  const [players, setPlayers] = useState<any[]>([]);
  const [loadingPlayers, setLoadingPlayers] = useState(true);
  const [startingGame, setStartingGame] = useState(false);
  
  const isCreator = room.creatorId === user?.id;
  const canStartGame = room.currentPlayers >= 2 && isCreator;
  const roomSettings = room.settings?.gameSettings;
  
  // Load players in the room
  useEffect(() => {
    const loadPlayers = async () => {
      setLoadingPlayers(true);
      try {
        // For now, simulate players based on room data
        // In a real implementation, you'd have a separate players table
        const roomPlayers = [];
        
        // Add creator
        if (room.creatorId) {
          const { data: creatorProfile } = await supabase
            .from('profiles')
            .select('*')
            .eq('id', room.creatorId)
            .maybeSingle();
          
          if (creatorProfile) {
            roomPlayers.push({
              id: creatorProfile.id,
              username: creatorProfile.username,
              isCreator: true,
            });
          }
        }
        
        // Add current user if they're not the creator
        if (user && user.id !== room.creatorId && profile) {
          roomPlayers.push({
            id: user.id,
            username: profile.username,
            isCreator: false,
          });
        }
        
        setPlayers(roomPlayers);
      } catch (error) {
        console.error('Error loading players:', error);
      } finally {
        setLoadingPlayers(false);
      }
    };
    
    loadPlayers();
  }, [room, user, profile]);
  
  const handleCopyRoomCode = async () => {
    const success = await copyToClipboard(room.roomCode);
    if (success) {
      toast.success('Room code copied to clipboard!');
    } else {
      toast.error('Failed to copy room code');
    }
  };
  
  const handleStartGame = async () => {
    if (!canStartGame) return;
    
    setStartingGame(true);
    try {
      // Create a new game
      const result = await gameService.createGame(
        room.id,
        players[0].id,
        players[1].id,
        roomSettings || {
          gridSize: 25,
          roundDuration: 120,
          maxRounds: 3,
          powerUpsEnabled: false,
        }
      );
      
      if (result.error) {
        toast.error(result.error);
      } else {
        toast.success('Game starting!');
        onStartGame(result.game!.id);
      }
    } catch (error) {
      console.error('Error starting game:', error);
      toast.error('Failed to start game');
    } finally {
      setStartingGame(false);
    }
  };
  
  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-blue-900 to-purple-900 p-4">
      <div className="max-w-2xl mx-auto py-8">
        {/* Header */}
        <div className="flex items-center gap-4 mb-8">
          <Button
            onClick={onGoBack}
            variant="ghost"
            size="sm"
            className="flex items-center gap-2"
          >
            <ArrowLeft className="w-4 h-4" />
            Back
          </Button>
          
          <div className="flex-1">
            <h1 className="text-2xl font-bold text-white">Game Room</h1>
            <p className="text-gray-400">Waiting for players to join</p>
          </div>
        </div>
        
        {/* Room Info */}
        <Card variant="glass" className="mb-6">
          <CardHeader>
            <div className="flex items-center justify-between">
              <div>
                <CardTitle className="flex items-center gap-2">
                  Room {room.roomCode}
                  <Button
                    onClick={handleCopyRoomCode}
                    variant="ghost"
                    size="sm"
                    className="h-6 px-2 text-xs"
                  >
                    <Copy className="w-3 h-3 mr-1" />
                    Copy
                  </Button>
                </CardTitle>
                <CardDescription>
                  Share this code with your friend to invite them
                </CardDescription>
              </div>
              
              <div className="text-right">
                <div className="text-2xl font-bold text-white">
                  {room.currentPlayers}/{room.maxPlayers}
                </div>
                <div className="text-xs text-gray-400">Players</div>
              </div>
            </div>
          </CardHeader>
          
          <CardContent>
            <div className="grid grid-cols-2 gap-4 text-sm">
              <div className="flex items-center justify-between">
                <span className="text-gray-400 flex items-center gap-1">
                  <Trophy className="w-4 h-4" />
                  Max Rounds
                </span>
                <span className="text-white font-medium">
                  {roomSettings?.maxRounds || 3}
                </span>
              </div>
              
              <div className="flex items-center justify-between">
                <span className="text-gray-400 flex items-center gap-1">
                  <Clock className="w-4 h-4" />
                  Round Duration
                </span>
                <span className="text-white font-medium">
                  {roomSettings?.roundDuration || 120}s
                </span>
              </div>
              
              <div className="flex items-center justify-between">
                <span className="text-gray-400 flex items-center gap-1">
                  <Settings className="w-4 h-4" />
                  Room Type
                </span>
                <span className="text-white font-medium">
                  {room.settings?.isPrivate ? 'Private' : 'Public'}
                </span>
              </div>
              
              <div className="flex items-center justify-between">
                <span className="text-gray-400 flex items-center gap-1">
                  <Settings className="w-4 h-4" />
                  Power-ups
                </span>
                <span className="text-white font-medium">
                  {roomSettings?.powerUpsEnabled ? 'Enabled' : 'Disabled'}
                </span>
              </div>
            </div>
          </CardContent>
        </Card>
        
        {/* Players */}
        <Card variant="default" className="mb-6">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Users className="w-5 h-5 text-blue-400" />
              Players ({room.currentPlayers}/{room.maxPlayers})
            </CardTitle>
            <CardDescription>
              {room.currentPlayers < room.maxPlayers
                ? 'Waiting for more players to join...'
                : 'All players ready!'}
            </CardDescription>
          </CardHeader>
          
          <CardContent>
            <div className="space-y-3">
              {loadingPlayers ? (
                Array.from({ length: 2 }, (_, i) => (
                  <div key={i} className="animate-pulse">
                    <div className="flex items-center gap-3 p-3">
                      <div className="w-10 h-10 bg-gray-700 rounded-full" />
                      <div className="flex-1">
                        <div className="w-24 h-4 bg-gray-700 rounded mb-1" />
                        <div className="w-16 h-3 bg-gray-700 rounded" />
                      </div>
                    </div>
                  </div>
                ))
              ) : (
                <>
                  {players.map((player) => (
                    <PlayerCard
                      key={player.id}
                      username={player.username}
                      isCreator={player.isCreator}
                      isYou={player.id === user?.id}
                    />
                  ))}
                  
                  {room.currentPlayers < room.maxPlayers && (
                    <EmptyPlayerSlot />
                  )}
                </>
              )}
            </div>
          </CardContent>
        </Card>
        
        {/* Actions */}
        <div className="flex gap-3">
          <Button
            onClick={onLeaveRoom}
            variant="outline"
            className="flex-1"
          >
            Leave Room
          </Button>
          
          {isCreator && (
            <Button
              onClick={handleStartGame}
              loading={startingGame}
              disabled={!canStartGame}
              className="flex-1 bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700"
            >
              {canStartGame ? (
                <>
                  <Play className="w-4 h-4 mr-2" />
                  Start Game
                </>
              ) : (
                'Waiting for Players'
              )}
            </Button>
          )}
          
          {!isCreator && (
            <div className="flex-1">
              <Card variant="glass" className="text-center p-4">
                <div className="text-yellow-400 mb-2">
                  <Crown className="w-6 h-6 mx-auto" />
                </div>
                <p className="text-sm text-gray-400">
                  Waiting for room creator to start the game
                </p>
              </Card>
            </div>
          )}
        </div>
        
        {/* Status Messages */}
        {room.currentPlayers < room.maxPlayers && (
          <motion.div
            className="mt-6 text-center"
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.5 }}
          >
            <div className="inline-flex items-center gap-2 bg-blue-900/30 text-blue-400 px-4 py-2 rounded-lg border border-blue-500/30">
              <div className="w-2 h-2 bg-blue-400 rounded-full animate-pulse" />
              <span className="text-sm">Room is open - share the code to invite players</span>
            </div>
          </motion.div>
        )}
      </div>
    </div>
  );
}