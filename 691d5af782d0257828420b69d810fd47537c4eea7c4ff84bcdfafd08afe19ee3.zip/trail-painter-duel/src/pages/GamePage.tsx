import React from 'react';
import { motion } from 'framer-motion';
import { GameBoard } from '../components/Game/GameBoard';
import { GameHUD } from '../components/Game/GameHUD';
import { GameResults } from '../components/Game/GameResults';
import { Button } from '../components/UI/Button';
import { useGame } from '../hooks/useGame';
import { useKeyboardControls, useTouchControls } from '../hooks/useControls';
import { useAuth } from '../hooks/useAuth';
import { ArrowLeft, Pause, Play } from 'lucide-react';
import { cn } from '../lib/utils';
import toast from 'react-hot-toast';

interface GamePageProps {
  gameId: string;
  onLeaveGame: () => void;
  onGameEnd: () => void;
}

export function GamePage({ gameId, onLeaveGame, onGameEnd }: GamePageProps) {
  const { user } = useAuth();
  const {
    game,
    gameState,
    gameLogic,
    players,
    isPlayer1,
    isPlayer2,
    myPlayerId,
    opponentId,
    movePlayer,
    leaveGame,
    isGameActive,
    isMyTurn,
    gameLoading,
    gameError,
    timeRemaining,
    currentRound,
    maxRounds,
    player1Score,
    player2Score,
    myTerritoryCount,
    opponentTerritoryCount,
    myTerritoryPercentage,
    opponentTerritoryPercentage,
  } = useGame(gameId);
  
  // Set up keyboard controls
  useKeyboardControls({
    onMove: movePlayer,
    enabled: isGameActive && !!myPlayerId,
  });
  
  // Set up touch controls for mobile
  useTouchControls({
    onMove: movePlayer,
    enabled: isGameActive && !!myPlayerId,
  });
  
  const handleLeaveGame = async () => {
    try {
      await leaveGame();
      onLeaveGame();
    } catch (error) {
      console.error('Error leaving game:', error);
      toast.error('Failed to leave game');
    }
  };
  
  const handlePlayAgain = () => {
    // Navigate back to lobby for rematch
    onGameEnd();
  };
  
  const handleGoHome = () => {
    onLeaveGame();
  };
  
  // Loading state
  if (gameLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-gray-900 via-blue-900 to-purple-900 flex items-center justify-center">
        <motion.div
          className="text-center"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
        >
          <div className="w-16 h-16 border-4 border-blue-500 border-t-transparent rounded-full animate-spin mx-auto mb-4" />
          <h2 className="text-xl font-semibold text-white mb-2">Loading Game...</h2>
          <p className="text-gray-400">Connecting to the battlefield</p>
        </motion.div>
      </div>
    );
  }
  
  // Error state
  if (gameError) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-gray-900 via-blue-900 to-purple-900 flex items-center justify-center p-4">
        <motion.div
          className="text-center max-w-md"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
        >
          <div className="w-16 h-16 bg-red-500/20 rounded-full flex items-center justify-center mx-auto mb-4">
            <ArrowLeft className="w-8 h-8 text-red-400" />
          </div>
          <h2 className="text-xl font-semibold text-white mb-2">Game Error</h2>
          <p className="text-gray-400 mb-6">{gameError}</p>
          <Button onClick={onLeaveGame} variant="outline">
            Back to Lobby
          </Button>
        </motion.div>
      </div>
    );
  }
  
  // No game data
  if (!game || !gameState) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-gray-900 via-blue-900 to-purple-900 flex items-center justify-center">
        <motion.div
          className="text-center"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
        >
          <h2 className="text-xl font-semibold text-white mb-2">Game Not Found</h2>
          <p className="text-gray-400 mb-4">The game you're looking for doesn't exist</p>
          <Button onClick={onLeaveGame} variant="outline">
            Back to Lobby
          </Button>
        </motion.div>
      </div>
    );
  }
  
  // Game finished - show results
  if (game.status === 'finished') {
    const winner = game.winnerId 
      ? players.find(p => p.id === game.winnerId) 
      : null;
    
    const finalScores = {
      player1: {
        username: players[0]?.username || 'Player 1',
        score: player1Score,
        territory: isPlayer1 ? myTerritoryPercentage : opponentTerritoryPercentage,
      },
      player2: {
        username: players[1]?.username || 'Player 2', 
        score: player2Score,
        territory: isPlayer2 ? myTerritoryPercentage : opponentTerritoryPercentage,
      },
    };
    
    const gameDuration = game.endedAt && game.startedAt 
      ? Math.floor((new Date(game.endedAt).getTime() - new Date(game.startedAt).getTime()) / 1000)
      : 0;
    
    return (
      <div className="min-h-screen bg-gradient-to-br from-gray-900 via-blue-900 to-purple-900 p-4">
        <div className="max-w-2xl mx-auto py-8">
          <GameResults
            winner={winner ? {
              id: winner.id,
              username: winner.username,
              color: winner.color,
            } : null}
            finalScores={finalScores}
            gameDuration={gameDuration}
            isPlayer={!!myPlayerId}
            myPlayerId={myPlayerId}
            onPlayAgain={handlePlayAgain}
            onGoHome={handleGoHome}
          />
        </div>
      </div>
    );
  }
  
  // Active game interface
  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-blue-900 to-purple-900 p-2 md:p-4">
      {/* Game Header */}
      <div className="flex items-center justify-between mb-4">
        <Button
          onClick={handleLeaveGame}
          variant="ghost"
          size="sm"
          className="flex items-center gap-2"
        >
          <ArrowLeft className="w-4 h-4" />
          Leave Game
        </Button>
        
        <div className="text-center">
          <h1 className="text-xl md:text-2xl font-bold text-white">Trail Painter Duel</h1>
          {opponentId && (
            <p className="text-sm text-gray-400">
              vs {players.find(p => p.id === opponentId)?.username || 'Opponent'}
            </p>
          )}
        </div>
        
        <div className="w-20" /> {/* Spacer for center alignment */}
      </div>
      
      {/* Main Game Area */}
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-4 max-w-7xl mx-auto">
        {/* Game Board */}
        <div className="lg:col-span-3 order-2 lg:order-1">
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.3 }}
            className="relative"
          >
            <GameBoard
              players={players}
              territoryData={gameState.territoryData}
              className="w-full max-w-2xl mx-auto"
            />
            
            {/* Game Status Overlay */}
            {!isGameActive && (
              <motion.div
                className="absolute inset-0 bg-black/50 backdrop-blur-sm rounded-lg flex items-center justify-center"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
              >
                <div className="text-center text-white">
                  <Pause className="w-12 h-12 mx-auto mb-2" />
                  <h3 className="text-xl font-semibold mb-1">Game Paused</h3>
                  <p className="text-gray-300">Waiting for round to start...</p>
                </div>
              </motion.div>
            )}
          </motion.div>
        </div>
        
        {/* Game HUD */}
        <div className="lg:col-span-1 order-1 lg:order-2">
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.3, delay: 0.1 }}
          >
            <GameHUD
              players={players}
              timeRemaining={timeRemaining}
              currentRound={currentRound}
              maxRounds={maxRounds}
              player1Score={player1Score}
              player2Score={player2Score}
              myPlayerId={myPlayerId}
              myTerritoryPercentage={myTerritoryPercentage}
              opponentTerritoryPercentage={opponentTerritoryPercentage}
              isGameActive={isGameActive}
            />
          </motion.div>
        </div>
      </div>
      
      {/* Mobile Touch Controls Hint */}
      <div className="fixed bottom-4 left-1/2 transform -translate-x-1/2 lg:hidden">
        <motion.div
          className="bg-gray-800/80 backdrop-blur-sm rounded-lg px-4 py-2 border border-gray-700/50"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 2, duration: 0.5 }}
        >
          <p className="text-xs text-gray-400 text-center">
            Swipe to move • Tap and drag to paint
          </p>
        </motion.div>
      </div>
    </div>
  );
}