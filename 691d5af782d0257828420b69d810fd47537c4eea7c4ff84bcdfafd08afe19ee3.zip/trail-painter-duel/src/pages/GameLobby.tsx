import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Plus, Users, Search, RefreshCw, Clock, Trophy } from 'lucide-react';
import { Button } from '../UI/Button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../UI/Card';
import { Input } from '../UI/Input';
import { GameRoom } from '../../types';
import { useGameRoom } from '../../hooks/useGameRoom';
import { cn } from '../../lib/utils';
import toast from 'react-hot-toast';

interface GameLobbyProps {
  onCreateRoom: () => void;
  onJoinRoom: (roomId: string) => void;
  onQuickPlay: () => void;
}

interface RoomCardProps {
  room: GameRoom;
  onJoin: (roomId: string) => void;
}

function RoomCard({ room, onJoin }: RoomCardProps) {
  const [joining, setJoining] = useState(false);
  
  const handleJoin = async () => {
    setJoining(true);
    try {
      onJoin(room.id);
    } finally {
      setJoining(false);
    }
  };
  
  const roomSettings = room.settings?.gameSettings;
  
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      whileHover={{ y: -2 }}
      transition={{ duration: 0.2 }}
    >
      <Card variant="glass" className="hover:border-blue-500/40 transition-colors">
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <CardTitle className="text-lg text-white">
              Room {room.roomCode}
            </CardTitle>
            <div className="flex items-center gap-1 text-xs text-green-400 bg-green-900/30 px-2 py-1 rounded">
              <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse" />
              Active
            </div>
          </div>
          <CardDescription className="text-gray-400">
            Waiting for players
          </CardDescription>
        </CardHeader>
        
        <CardContent className="space-y-3">
          <div className="flex items-center justify-between text-sm">
            <span className="text-gray-400 flex items-center gap-1">
              <Users className="w-4 h-4" />
              Players
            </span>
            <span className="text-white font-medium">
              {room.currentPlayers}/{room.maxPlayers}
            </span>
          </div>
          
          <div className="flex items-center justify-between text-sm">
            <span className="text-gray-400 flex items-center gap-1">
              <Clock className="w-4 h-4" />
              Round Duration
            </span>
            <span className="text-white font-medium">
              {roomSettings?.roundDuration || 120}s
            </span>
          </div>
          
          <div className="flex items-center justify-between text-sm">
            <span className="text-gray-400 flex items-center gap-1">
              <Trophy className="w-4 h-4" />
              Max Rounds
            </span>
            <span className="text-white font-medium">
              {roomSettings?.maxRounds || 3}
            </span>
          </div>
          
          <Button
            onClick={handleJoin}
            loading={joining}
            className="w-full mt-4"
            disabled={room.currentPlayers >= room.maxPlayers}
          >
            {room.currentPlayers >= room.maxPlayers ? 'Room Full' : 'Join Room'}
          </Button>
        </CardContent>
      </Card>
    </motion.div>
  );
}

function QuickJoinCard({ onJoinByCode }: { onJoinByCode: (code: string) => void }) {
  const [roomCode, setRoomCode] = useState('');
  const [joining, setJoining] = useState(false);
  
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!roomCode.trim()) {
      toast.error('Please enter a room code');
      return;
    }
    
    setJoining(true);
    try {
      onJoinByCode(roomCode.trim().toUpperCase());
    } finally {
      setJoining(false);
    }
  };
  
  return (
    <Card variant="highlight">
      <CardHeader>
        <CardTitle className="text-lg flex items-center gap-2">
          <Search className="w-5 h-5 text-blue-400" />
          Quick Join
        </CardTitle>
        <CardDescription>
          Enter a room code to join directly
        </CardDescription>
      </CardHeader>
      
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-3">
          <Input
            placeholder="Enter room code (e.g., ABC123)"
            value={roomCode}
            onChange={(e) => setRoomCode(e.target.value.toUpperCase())}
            maxLength={6}
            className="text-center font-mono text-lg"
            disabled={joining}
          />
          <Button
            type="submit"
            loading={joining}
            className="w-full"
            disabled={!roomCode.trim()}
          >
            Join Room
          </Button>
        </form>
      </CardContent>
    </Card>
  );
}

export function GameLobby({ onCreateRoom, onJoinRoom, onQuickPlay }: GameLobbyProps) {
  const { 
    availableRooms, 
    refreshAvailableRooms, 
    roomLoading, 
    joinRoom 
  } = useGameRoom();
  
  const [refreshing, setRefreshing] = useState(false);
  
  const handleRefresh = async () => {
    setRefreshing(true);
    try {
      await refreshAvailableRooms();
      toast.success('Rooms refreshed');
    } catch (error) {
      toast.error('Failed to refresh rooms');
    } finally {
      setRefreshing(false);
    }
  };
  
  const handleJoinByCode = async (roomCode: string) => {
    const result = await joinRoom(roomCode);
    if (result.success && result.room) {
      onJoinRoom(result.room.id);
    }
  };
  
  const handleJoinRoom = async (roomId: string) => {
    onJoinRoom(roomId);
  };
  
  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="text-center">
        <motion.h1 
          className="text-4xl font-bold text-white mb-2"
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
        >
          Game Lobby
        </motion.h1>
        <motion.p 
          className="text-gray-400"
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
        >
          Create a room or join an existing game
        </motion.p>
      </div>
      
      {/* Quick Actions */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
        >
          <Card variant="gradient" className="h-full">
            <CardContent className="text-center">
              <div className="w-12 h-12 bg-gradient-to-br from-green-600 to-blue-600 rounded-full flex items-center justify-center mx-auto mb-3">
                <Plus className="w-6 h-6 text-white" />
              </div>
              <h3 className="text-lg font-semibold text-white mb-2">Create Room</h3>
              <p className="text-gray-400 text-sm mb-4">Start a new game with custom settings</p>
              <Button onClick={onCreateRoom} className="w-full" variant="success">
                Create Room
              </Button>
            </CardContent>
          </Card>
        </motion.div>
        
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
        >
          <QuickJoinCard onJoinByCode={handleJoinByCode} />
        </motion.div>
        
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
        >
          <Card variant="gradient" className="h-full">
            <CardContent className="text-center">
              <div className="w-12 h-12 bg-gradient-to-br from-purple-600 to-pink-600 rounded-full flex items-center justify-center mx-auto mb-3">
                <Users className="w-6 h-6 text-white" />
              </div>
              <h3 className="text-lg font-semibold text-white mb-2">Quick Play</h3>
              <p className="text-gray-400 text-sm mb-4">Jump into a random available game</p>
              <Button 
                onClick={onQuickPlay} 
                className="w-full" 
                variant="warning"
                disabled={availableRooms.length === 0}
              >
                {availableRooms.length === 0 ? 'No Games Available' : 'Quick Play'}
              </Button>
            </CardContent>
          </Card>
        </motion.div>
      </div>
      
      {/* Available Rooms */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="text-2xl font-semibold text-white">Available Rooms</h2>
          <Button
            onClick={handleRefresh}
            loading={refreshing}
            variant="ghost"
            size="sm"
            className="flex items-center gap-2"
          >
            <RefreshCw className={cn('w-4 h-4', refreshing && 'animate-spin')} />
            Refresh
          </Button>
        </div>
        
        {roomLoading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {Array.from({ length: 3 }, (_, i) => (
              <div key={i} className="animate-pulse">
                <div className="bg-gray-800/50 rounded-xl h-48" />
              </div>
            ))}
          </div>
        ) : availableRooms.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {availableRooms.map((room) => (
              <RoomCard
                key={room.id}
                room={room}
                onJoin={handleJoinRoom}
              />
            ))}
          </div>
        ) : (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="text-center py-12"
          >
            <div className="w-16 h-16 bg-gray-800 rounded-full flex items-center justify-center mx-auto mb-4">
              <Users className="w-8 h-8 text-gray-600" />
            </div>
            <h3 className="text-xl font-semibold text-gray-400 mb-2">No Active Rooms</h3>
            <p className="text-gray-500 mb-4">Be the first to create a room!</p>
            <Button onClick={onCreateRoom} variant="default">
              Create Room
            </Button>
          </motion.div>
        )}
      </div>
    </div>
  );
}