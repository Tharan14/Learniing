import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Trophy, Medal, Target, ArrowLeft, Crown, Star, TrendingUp, Users } from 'lucide-react';
import { Button } from '../components/UI/Button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../components/UI/Card';
import { authService } from '../services/authService';
import { useAuth } from '../hooks/useAuth';
import { cn } from '../lib/utils';
import { gameUtils } from '../utils';

interface LeaderboardPageProps {
  onGoBack: () => void;
}

interface LeaderboardEntry {
  rank: number;
  username: string;
  gamesWon: number;
  gamesPlayed: number;
  winRate: number;
  totalTerritoryPainted: number;
}

interface PlayerCardProps {
  player: LeaderboardEntry;
  isCurrentPlayer: boolean;
}

function PlayerCard({ player, isCurrentPlayer }: PlayerCardProps) {
  const getRankIcon = (rank: number) => {
    switch (rank) {
      case 1:
        return <Crown className="w-5 h-5 text-yellow-400" />;
      case 2:
        return <Medal className="w-5 h-5 text-gray-400" />;
      case 3:
        return <Medal className="w-5 h-5 text-orange-500" />;
      default:
        return <span className="text-sm font-bold text-gray-400">#{rank}</span>;
    }
  };
  
  const getRankColor = (rank: number) => {
    switch (rank) {
      case 1:
        return 'from-yellow-500/20 to-yellow-600/20 border-yellow-500/40';
      case 2:
        return 'from-gray-400/20 to-gray-500/20 border-gray-400/40';
      case 3:
        return 'from-orange-500/20 to-orange-600/20 border-orange-500/40';
      default:
        return 'from-gray-800/20 to-gray-900/20 border-gray-700/40';
    }
  };
  
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: player.rank * 0.05 }}
    >
      <Card 
        variant="glass" 
        className={cn(
          'bg-gradient-to-r',
          getRankColor(player.rank),
          isCurrentPlayer && 'ring-2 ring-blue-400/60'
        )}
      >
        <CardContent className="flex items-center gap-4">
          {/* Rank */}
          <div className="flex items-center justify-center w-12 h-12 rounded-full bg-gray-800/50">
            {getRankIcon(player.rank)}
          </div>
          
          {/* Player Info */}
          <div className="flex-1">
            <div className="flex items-center gap-2 mb-1">
              <h3 className="text-white font-semibold">{player.username}</h3>
              {isCurrentPlayer && (
                <span className="text-xs text-blue-400 bg-blue-900/30 px-2 py-1 rounded">
                  You
                </span>
              )}
            </div>
            <div className="flex items-center gap-4 text-sm text-gray-400">
              <span className="flex items-center gap-1">
                <Trophy className="w-3 h-3" />
                {player.gamesWon} wins
              </span>
              <span className="flex items-center gap-1">
                <Users className="w-3 h-3" />
                {player.gamesPlayed} games
              </span>
              <span className="flex items-center gap-1">
                <Target className="w-3 h-3" />
                {player.winRate}%
              </span>
            </div>
          </div>
          
          {/* Win Rate Badge */}
          <div className="text-right">
            <div className={cn(
              'text-lg font-bold',
              player.winRate >= 70 ? 'text-green-400' :
              player.winRate >= 50 ? 'text-yellow-400' :
              player.winRate >= 30 ? 'text-orange-400' :
              'text-red-400'
            )}>
              {player.winRate}%
            </div>
            <div className="text-xs text-gray-400">Win Rate</div>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}

function StatsCard({ 
  icon, 
  label, 
  value, 
  description, 
  color = 'blue' 
}: {
  icon: React.ReactNode;
  label: string;
  value: string | number;
  description: string;
  color?: 'blue' | 'green' | 'yellow' | 'purple';
}) {
  const colorClasses = {
    blue: 'from-blue-600 to-blue-700',
    green: 'from-green-600 to-green-700',
    yellow: 'from-yellow-600 to-yellow-700',
    purple: 'from-purple-600 to-purple-700',
  };
  
  return (
    <Card variant="glass">
      <CardContent className="text-center">
        <div className={cn(
          'w-12 h-12 mx-auto mb-3 bg-gradient-to-br rounded-full flex items-center justify-center',
          colorClasses[color]
        )}>
          {icon}
        </div>
        <h3 className="text-2xl font-bold text-white mb-1">{value}</h3>
        <p className="text-sm font-medium text-gray-300 mb-1">{label}</p>
        <p className="text-xs text-gray-400">{description}</p>
      </CardContent>
    </Card>
  );
}

export function LeaderboardPage({ onGoBack }: LeaderboardPageProps) {
  const { user, profile } = useAuth();
  const [leaderboard, setLeaderboard] = useState<LeaderboardEntry[]>([]);
  const [loading, setLoading] = useState(true);
  const [totalPlayers, setTotalPlayers] = useState(0);
  const [totalGames, setTotalGames] = useState(0);
  
  useEffect(() => {
    const loadLeaderboard = async () => {
      setLoading(true);
      try {
        const data = await authService.getLeaderboard(50);
        setLeaderboard(data);
        
        // Calculate stats
        setTotalPlayers(data.length);
        setTotalGames(data.reduce((sum, player) => sum + player.gamesPlayed, 0));
      } catch (error) {
        console.error('Error loading leaderboard:', error);
      } finally {
        setLoading(false);
      }
    };
    
    loadLeaderboard();
  }, []);
  
  const myRank = leaderboard.findIndex(player => player.username === profile?.username) + 1;
  const topPlayers = leaderboard.slice(0, 10);
  
  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-blue-900 to-purple-900 p-4">
      <div className="max-w-4xl mx-auto py-8">
        {/* Header */}
        <div className="flex items-center gap-4 mb-8">
          <Button
            onClick={onGoBack}
            variant="ghost"
            size="sm"
            className="flex items-center gap-2"
          >
            <ArrowLeft className="w-4 h-4" />
            Back
          </Button>
          
          <div className="flex-1">
            <h1 className="text-3xl font-bold text-white mb-2">Leaderboard</h1>
            <p className="text-gray-400">
              See how you rank against other Trail Painter Duel players
            </p>
          </div>
        </div>
        
        {/* Global Stats */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          <StatsCard
            icon={<Users className="w-6 h-6 text-white" />}
            label="Total Players"
            value={totalPlayers}
            description="Active players"
            color="blue"
          />
          
          <StatsCard
            icon={<Trophy className="w-6 h-6 text-white" />}
            label="Total Games"
            value={totalGames}
            description="Games played"
            color="green"
          />
          
          <StatsCard
            icon={<TrendingUp className="w-6 h-6 text-white" />}
            label="Avg Win Rate"
            value={`${Math.round(leaderboard.reduce((sum, p) => sum + p.winRate, 0) / Math.max(leaderboard.length, 1))}%`}
            description="Community average"
            color="yellow"
          />
          
          <StatsCard
            icon={<Star className="w-6 h-6 text-white" />}
            label="Your Rank"
            value={myRank || 'Unranked'}
            description={myRank ? `Out of ${totalPlayers}` : 'Play to get ranked'}
            color="purple"
          />
        </div>
        
        {/* Your Stats */}
        {profile && myRank > 0 && (
          <Card variant="highlight" className="mb-8">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Star className="w-5 h-5 text-blue-400" />
                Your Performance
              </CardTitle>
              <CardDescription>
                Your current ranking and statistics
              </CardDescription>
            </CardHeader>
            
            <CardContent>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div className="text-center">
                  <div className="text-2xl font-bold text-white mb-1">#{myRank}</div>
                  <div className="text-sm text-gray-400">Global Rank</div>
                </div>
                
                <div className="text-center">
                  <div className="text-2xl font-bold text-green-400 mb-1">{profile.gamesWon}</div>
                  <div className="text-sm text-gray-400">Games Won</div>
                </div>
                
                <div className="text-center">
                  <div className="text-2xl font-bold text-blue-400 mb-1">{profile.gamesPlayed}</div>
                  <div className="text-sm text-gray-400">Games Played</div>
                </div>
                
                <div className="text-center">
                  <div className="text-2xl font-bold text-yellow-400 mb-1">
                    {gameUtils.calculateWinRate(profile.gamesWon, profile.gamesPlayed)}%
                  </div>
                  <div className="text-sm text-gray-400">Win Rate</div>
                </div>
              </div>
            </CardContent>
          </Card>
        )}
        
        {/* Top Players */}
        <Card variant="default">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Trophy className="w-5 h-5 text-yellow-400" />
              Top Players
            </CardTitle>
            <CardDescription>
              The best Trail Painter Duel players worldwide
            </CardDescription>
          </CardHeader>
          
          <CardContent>
            {loading ? (
              <div className="space-y-4">
                {Array.from({ length: 10 }, (_, i) => (
                  <div key={i} className="animate-pulse">
                    <div className="flex items-center gap-4 p-4">
                      <div className="w-12 h-12 bg-gray-700 rounded-full" />
                      <div className="flex-1">
                        <div className="w-32 h-4 bg-gray-700 rounded mb-2" />
                        <div className="w-48 h-3 bg-gray-700 rounded" />
                      </div>
                      <div className="w-16 h-6 bg-gray-700 rounded" />
                    </div>
                  </div>
                ))}
              </div>
            ) : leaderboard.length > 0 ? (
              <div className="space-y-3">
                {topPlayers.map((player) => (
                  <PlayerCard
                    key={player.username}
                    player={player}
                    isCurrentPlayer={player.username === profile?.username}
                  />
                ))}
                
                {leaderboard.length > 10 && (
                  <div className="text-center pt-4">
                    <p className="text-gray-400 text-sm">
                      Showing top 10 players out of {leaderboard.length} total
                    </p>
                  </div>
                )}
              </div>
            ) : (
              <div className="text-center py-12">
                <Trophy className="w-16 h-16 text-gray-600 mx-auto mb-4" />
                <h3 className="text-xl font-semibold text-gray-400 mb-2">
                  No Rankings Yet
                </h3>
                <p className="text-gray-500 mb-4">
                  Be the first to play and claim the top spot!
                </p>
                <Button onClick={onGoBack} variant="default">
                  Start Playing
                </Button>
              </div>
            )}
          </CardContent>
        </Card>
        
        {/* Ranking Info */}
        <motion.div
          className="mt-8 text-center"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
        >
          <Card variant="glass">
            <CardContent className="text-center">
              <h3 className="text-lg font-semibold text-white mb-2">How Rankings Work</h3>
              <p className="text-gray-400 text-sm">
                Players are ranked by games won, with win rate as the tiebreaker. 
                Play more games to climb the leaderboard and show your skills!
              </p>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </div>
  );
}