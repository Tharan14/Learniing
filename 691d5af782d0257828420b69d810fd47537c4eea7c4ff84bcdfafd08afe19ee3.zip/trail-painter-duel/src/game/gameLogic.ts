import { Position, Direction, GameCell, Player, GRID_SIZE, PLAYER_COLORS } from '../types';

/**
 * Core game logic for Trail Painter Duel
 * Handles movement, territory painting, collision detection, and scoring
 */

export class GameLogic {
  private gridSize: number;
  private territory: Map<string, string>; // "x,y" -> playerId

  constructor(gridSize: number = GRID_SIZE) {
    this.gridSize = gridSize;
    this.territory = new Map();
  }

  /**
   * Get the key for a position in the territory map
   */
  private getPositionKey(position: Position): string {
    return `${position.x},${position.y}`;
  }

  /**
   * Check if a position is within the game grid bounds
   */
  isValidPosition(position: Position): boolean {
    return (
      position.x >= 0 &&
      position.x < this.gridSize &&
      position.y >= 0 &&
      position.y < this.gridSize
    );
  }

  /**
   * Calculate new position based on current position and direction
   */
  calculateNewPosition(currentPosition: Position, direction: Direction): Position {
    const { x, y } = currentPosition;
    
    switch (direction) {
      case 'up':
        return { x, y: Math.max(0, y - 1) };
      case 'down':
        return { x, y: Math.min(this.gridSize - 1, y + 1) };
      case 'left':
        return { x: Math.max(0, x - 1), y };
      case 'right':
        return { x: Math.min(this.gridSize - 1, x + 1), y };
      default:
        return currentPosition;
    }
  }

  /**
   * Move a player in the specified direction and paint territory
   */
  movePlayer(playerId: string, currentPosition: Position, direction: Direction): {
    newPosition: Position;
    territoryPainted: boolean;
    cellsChanged: Position[];
  } {
    const newPosition = this.calculateNewPosition(currentPosition, direction);
    
    // If position didn't change (hit boundary), no territory is painted
    if (newPosition.x === currentPosition.x && newPosition.y === currentPosition.y) {
      return {
        newPosition,
        territoryPainted: false,
        cellsChanged: []
      };
    }

    // Paint the new cell
    const positionKey = this.getPositionKey(newPosition);
    const previousOwner = this.territory.get(positionKey);
    this.territory.set(positionKey, playerId);

    return {
      newPosition,
      territoryPainted: true,
      cellsChanged: [newPosition]
    };
  }

  /**
   * Get the owner of a specific cell
   */
  getCellOwner(position: Position): string | null {
    return this.territory.get(this.getPositionKey(position)) || null;
  }

  /**
   * Set the territory state from a data object
   */
  setTerritoryData(territoryData: Record<string, string>): void {
    this.territory.clear();
    Object.entries(territoryData).forEach(([key, playerId]) => {
      this.territory.set(key, playerId);
    });
  }

  /**
   * Get current territory data as a plain object
   */
  getTerritoryData(): Record<string, string> {
    const data: Record<string, string> = {};
    this.territory.forEach((playerId, positionKey) => {
      data[positionKey] = playerId;
    });
    return data;
  }

  /**
   * Calculate territory count for each player
   */
  calculateTerritoryCount(): Record<string, number> {
    const counts: Record<string, number> = {};
    
    this.territory.forEach((playerId) => {
      counts[playerId] = (counts[playerId] || 0) + 1;
    });
    
    return counts;
  }

  /**
   * Get territory percentage for a player
   */
  getTerritoryPercentage(playerId: string): number {
    const totalCells = this.gridSize * this.gridSize;
    const playerCells = this.getPlayerTerritoryCount(playerId);
    return (playerCells / totalCells) * 100;
  }

  /**
   * Get territory count for a specific player
   */
  getPlayerTerritoryCount(playerId: string): number {
    let count = 0;
    this.territory.forEach((owner) => {
      if (owner === playerId) count++;
    });
    return count;
  }

  /**
   * Determine the winner based on territory count
   */
  determineWinner(player1Id: string, player2Id: string): {
    winnerId: string | null;
    player1Territory: number;
    player2Territory: number;
    isDraw: boolean;
  } {
    const player1Territory = this.getPlayerTerritoryCount(player1Id);
    const player2Territory = this.getPlayerTerritoryCount(player2Id);
    
    let winnerId: string | null = null;
    let isDraw = false;
    
    if (player1Territory > player2Territory) {
      winnerId = player1Id;
    } else if (player2Territory > player1Territory) {
      winnerId = player2Id;
    } else {
      isDraw = true;
    }
    
    return {
      winnerId,
      player1Territory,
      player2Territory,
      isDraw
    };
  }

  /**
   * Reset the game state for a new round
   */
  resetGame(): void {
    this.territory.clear();
  }

  /**
   * Get all painted cells with their owners
   */
  getPaintedCells(): GameCell[] {
    const cells: GameCell[] = [];
    
    this.territory.forEach((playerId, positionKey) => {
      const [x, y] = positionKey.split(',').map(Number);
      cells.push({
        x,
        y,
        owner: playerId,
        lastPainted: Date.now()
      });
    });
    
    return cells;
  }

  /**
   * Check if two players are on the same cell (collision)
   */
  checkPlayerCollision(player1Position: Position, player2Position: Position): boolean {
    return player1Position.x === player2Position.x && player1Position.y === player2Position.y;
  }

  /**
   * Generate starting positions for players
   */
  getStartingPositions(): { player1: Position; player2: Position } {
    return {
      player1: { x: 2, y: 2 },
      player2: { x: this.gridSize - 3, y: this.gridSize - 3 }
    };
  }

  /**
   * Validate if a move is legal (not out of bounds, not too fast)
   */
  validateMove(
    currentPosition: Position,
    newPosition: Position,
    lastMoveTime: number,
    minMoveInterval: number = 100 // ms
  ): {
    isValid: boolean;
    reason?: string;
  } {
    const now = Date.now();
    
    // Check move timing
    if (now - lastMoveTime < minMoveInterval) {
      return {
        isValid: false,
        reason: 'Move too fast'
      };
    }
    
    // Check if move is adjacent
    const dx = Math.abs(newPosition.x - currentPosition.x);
    const dy = Math.abs(newPosition.y - currentPosition.y);
    
    if ((dx === 1 && dy === 0) || (dx === 0 && dy === 1)) {
      return {
        isValid: true
      };
    }
    
    return {
      isValid: false,
      reason: 'Invalid move distance'
    };
  }

  /**
   * Get game statistics for display
   */
  getGameStats(player1Id: string, player2Id: string): {
    player1Territory: number;
    player2Territory: number;
    totalPaintedCells: number;
    neutralCells: number;
  } {
    const player1Territory = this.getPlayerTerritoryCount(player1Id);
    const player2Territory = this.getPlayerTerritoryCount(player2Id);
    const totalPaintedCells = player1Territory + player2Territory;
    const totalCells = this.gridSize * this.gridSize;
    const neutralCells = totalCells - totalPaintedCells;
    
    return {
      player1Territory,
      player2Territory,
      totalPaintedCells,
      neutralCells
    };
  }
}

// Helper functions for game logic
export const gameUtils = {
  /**
   * Generate a random room code
   */
  generateRoomCode(): string {
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    let result = '';
    for (let i = 0; i < 6; i++) {
      result += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return result;
  },

  /**
   * Format time in MM:SS format
   */
  formatTime(seconds: number): string {
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = seconds % 60;
    return `${minutes}:${remainingSeconds.toString().padStart(2, '0')}`;
  },

  /**
   * Calculate win rate percentage
   */
  calculateWinRate(gamesWon: number, gamesPlayed: number): number {
    if (gamesPlayed === 0) return 0;
    return Math.round((gamesWon / gamesPlayed) * 100);
  },

  /**
   * Get player color based on player number
   */
  getPlayerColor(playerNumber: 1 | 2): string {
    return playerNumber === 1 ? PLAYER_COLORS.PLAYER_1 : PLAYER_COLORS.PLAYER_2;
  },

  /**
   * Debounce function for limiting rapid moves
   */
  debounce<T extends (...args: any[]) => any>(
    func: T,
    delay: number
  ): (...args: Parameters<T>) => void {
    let timeoutId: NodeJS.Timeout;
    return (...args: Parameters<T>) => {
      clearTimeout(timeoutId);
      timeoutId = setTimeout(() => func(...args), delay);
    };
  }
};