import { createClient } from '@supabase/supabase-js';
import { Database } from '../types/database';

// Environment variables - Replace with your actual Supabase credentials
// Get these from your Supabase project settings: https://app.supabase.com/project/_/settings/api
const supabaseUrl = import.meta.env.VITE_SUPABASE_URL || 'YOUR_SUPABASE_URL_HERE';
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY || 'YOUR_SUPABASE_ANON_KEY_HERE';

// Create Supabase client instance
export const supabase = createClient(supabaseUrl, supabaseAnonKey, {
  realtime: {
    params: {
      eventsPerSecond: 20, // Optimize for real-time game updates
    },
  },
});

// Type-safe Supabase client
export type SupabaseClient = typeof supabase;

// Database types (these will be generated based on your actual schema)
export interface Database {
  public: {
    Tables: {
      profiles: {
        Row: {
          id: string;
          username: string;
          avatar_url: string | null;
          games_played: number;
          games_won: number;
          total_territory_painted: number;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id: string;
          username: string;
          avatar_url?: string | null;
          games_played?: number;
          games_won?: number;
          total_territory_painted?: number;
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          id?: string;
          username?: string;
          avatar_url?: string | null;
          games_played?: number;
          games_won?: number;
          total_territory_painted?: number;
          created_at?: string;
          updated_at?: string;
        };
      };
      game_rooms: {
        Row: {
          id: string;
          room_code: string;
          creator_id: string;
          status: string;
          max_players: number;
          current_players: number;
          settings: any;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          room_code: string;
          creator_id: string;
          status?: string;
          max_players?: number;
          current_players?: number;
          settings?: any;
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          id?: string;
          room_code?: string;
          creator_id?: string;
          status?: string;
          max_players?: number;
          current_players?: number;
          settings?: any;
          created_at?: string;
          updated_at?: string;
        };
      };
      games: {
        Row: {
          id: string;
          room_id: string;
          player1_id: string;
          player2_id: string | null;
          status: string;
          current_round: number;
          max_rounds: number;
          player1_score: number;
          player2_score: number;
          winner_id: string | null;
          game_settings: any;
          started_at: string | null;
          ended_at: string | null;
          created_at: string;
        };
        Insert: {
          id?: string;
          room_id: string;
          player1_id: string;
          player2_id?: string | null;
          status?: string;
          current_round?: number;
          max_rounds?: number;
          player1_score?: number;
          player2_score?: number;
          winner_id?: string | null;
          game_settings?: any;
          started_at?: string | null;
          ended_at?: string | null;
          created_at?: string;
        };
        Update: {
          id?: string;
          room_id?: string;
          player1_id?: string;
          player2_id?: string | null;
          status?: string;
          current_round?: number;
          max_rounds?: number;
          player1_score?: number;
          player2_score?: number;
          winner_id?: string | null;
          game_settings?: any;
          started_at?: string | null;
          ended_at?: string | null;
          created_at?: string;
        };
      };
      game_states: {
        Row: {
          id: string;
          game_id: string;
          round_number: number;
          player1_position: any;
          player2_position: any;
          territory_data: any;
          round_time_remaining: number;
          round_status: string;
          player1_territory_count: number;
          player2_territory_count: number;
          last_updated: string;
        };
        Insert: {
          id?: string;
          game_id: string;
          round_number: number;
          player1_position?: any;
          player2_position?: any;
          territory_data?: any;
          round_time_remaining?: number;
          round_status?: string;
          player1_territory_count?: number;
          player2_territory_count?: number;
          last_updated?: string;
        };
        Update: {
          id?: string;
          game_id?: string;
          round_number?: number;
          player1_position?: any;
          player2_position?: any;
          territory_data?: any;
          round_time_remaining?: number;
          round_status?: string;
          player1_territory_count?: number;
          player2_territory_count?: number;
          last_updated?: string;
        };
      };
      match_history: {
        Row: {
          id: string;
          game_id: string;
          player_id: string;
          opponent_id: string;
          result: string;
          final_score: number;
          opponent_score: number;
          territory_painted: number;
          rounds_won: number;
          duration_seconds: number;
          played_at: string;
        };
        Insert: {
          id?: string;
          game_id: string;
          player_id: string;
          opponent_id: string;
          result: string;
          final_score: number;
          opponent_score: number;
          territory_painted?: number;
          rounds_won?: number;
          duration_seconds?: number;
          played_at?: string;
        };
        Update: {
          id?: string;
          game_id?: string;
          player_id?: string;
          opponent_id?: string;
          result?: string;
          final_score?: number;
          opponent_score?: number;
          territory_painted?: number;
          rounds_won?: number;
          duration_seconds?: number;
          played_at?: string;
        };
      };
    };
    Views: {
      [_ in never]: never;
    };
    Functions: {
      [_ in never]: never;
    };
    Enums: {
      [_ in never]: never;
    };
  };
}

// Helper function to get current user
export async function getCurrentUser() {
  const { data: { user }, error } = await supabase.auth.getUser();
  if (error) {
    console.error('Error getting user:', error);
    return null;
  }
  return user;
}

// Helper function to sign out
export async function signOut() {
  const { error } = await supabase.auth.signOut();
  if (error) {
    console.error('Error signing out:', error);
    throw error;
  }
}

// Real-time subscription helper
export function subscribeToGameState(
  gameId: string,
  callback: (payload: any) => void
) {
  return supabase
    .channel(`game-state-${gameId}`)
    .on(
      'postgres_changes',
      {
        event: '*',
        schema: 'public',
        table: 'game_states',
        filter: `game_id=eq.${gameId}`,
      },
      callback
    )
    .subscribe();
}

// Real-time subscription for game rooms
export function subscribeToGameRoom(
  roomId: string,
  callback: (payload: any) => void
) {
  return supabase
    .channel(`game-room-${roomId}`)
    .on(
      'postgres_changes',
      {
        event: '*',
        schema: 'public',
        table: 'game_rooms',
        filter: `id=eq.${roomId}`,
      },
      callback
    )
    .subscribe();
}

// Real-time subscription for games
export function subscribeToGame(
  gameId: string,
  callback: (payload: any) => void
) {
  return supabase
    .channel(`game-${gameId}`)
    .on(
      'postgres_changes',
      {
        event: '*',
        schema: 'public',
        table: 'games',
        filter: `id=eq.${gameId}`,
      },
      callback
    )
    .subscribe();
}