import { supabase } from './supabase';
import { Profile, LoginForm, SignupForm } from '../types';

/**
 * Authentication service for user management
 */
export class AuthService {
  /**
   * Sign up a new user
   */
  async signUp(formData: SignupForm): Promise<{
    user: any;
    error: null;
  } | {
    user: null;
    error: string;
  }> {
    try {
      const { data, error } = await supabase.auth.signUp({
        email: formData.email,
        password: formData.password,
        options: {
          data: {
            username: formData.username,
          },
        },
      });

      if (error) {
        return { user: null, error: error.message };
      }

      // Create user profile
      if (data.user) {
        await this.createUserProfile(data.user.id, formData.username);
      }

      return { user: data.user, error: null };
    } catch (error: any) {
      return { user: null, error: error.message || 'Failed to sign up' };
    }
  }

  /**
   * Sign in an existing user
   */
  async signIn(formData: LoginForm): Promise<{
    user: any;
    error: null;
  } | {
    user: null;
    error: string;
  }> {
    try {
      const { data, error } = await supabase.auth.signInWithPassword({
        email: formData.email,
        password: formData.password,
      });

      if (error) {
        return { user: null, error: error.message };
      }

      return { user: data.user, error: null };
    } catch (error: any) {
      return { user: null, error: error.message || 'Failed to sign in' };
    }
  }

  /**
   * Sign out the current user
   */
  async signOut(): Promise<{ error: string | null }> {
    try {
      const { error } = await supabase.auth.signOut();
      if (error) {
        return { error: error.message };
      }
      return { error: null };
    } catch (error: any) {
      return { error: error.message || 'Failed to sign out' };
    }
  }

  /**
   * Get current user
   */
  async getCurrentUser() {
    try {
      const { data: { user }, error } = await supabase.auth.getUser();
      if (error) {
        console.error('Error getting user:', error);
        return null;
      }
      return user;
    } catch (error) {
      console.error('Error getting user:', error);
      return null;
    }
  }

  /**
   * Create user profile after signup
   */
  private async createUserProfile(userId: string, username: string): Promise<void> {
    try {
      const { error } = await supabase
        .from('profiles')
        .insert({
          id: userId,
          username: username,
          games_played: 0,
          games_won: 0,
          total_territory_painted: 0,
        });

      if (error) {
        console.error('Error creating user profile:', error);
      }
    } catch (error) {
      console.error('Error creating user profile:', error);
    }
  }

  /**
   * Get user profile
   */
  async getUserProfile(userId: string): Promise<Profile | null> {
    try {
      const { data, error } = await supabase
        .from('profiles')
        .select('*')
        .eq('id', userId)
        .maybeSingle();

      if (error) {
        console.error('Error fetching user profile:', error);
        return null;
      }

      return data as Profile;
    } catch (error) {
      console.error('Error fetching user profile:', error);
      return null;
    }
  }

  /**
   * Update user profile
   */
  async updateUserProfile(
    userId: string,
    updates: Partial<Profile>
  ): Promise<{ success: boolean; error: string | null }> {
    try {
      const { error } = await supabase
        .from('profiles')
        .update({
          ...updates,
          updated_at: new Date().toISOString(),
        })
        .eq('id', userId);

      if (error) {
        console.error('Error updating user profile:', error);
        return { success: false, error: 'Failed to update profile' };
      }

      return { success: true, error: null };
    } catch (error: any) {
      console.error('Error updating user profile:', error);
      return { success: false, error: error.message || 'Failed to update profile' };
    }
  }

  /**
   * Check if username is available
   */
  async isUsernameAvailable(username: string): Promise<boolean> {
    try {
      const { data, error } = await supabase
        .from('profiles')
        .select('username')
        .eq('username', username)
        .maybeSingle();

      if (error && error.code !== 'PGRST116') {
        console.error('Error checking username availability:', error);
        return false;
      }

      return !data; // Username is available if no data is returned
    } catch (error) {
      console.error('Error checking username availability:', error);
      return false;
    }
  }

  /**
   * Get user's match history
   */
  async getUserMatchHistory(userId: string, limit: number = 20): Promise<any[]> {
    try {
      const { data, error } = await supabase
        .from('match_history')
        .select('*')
        .eq('player_id', userId)
        .order('played_at', { ascending: false })
        .limit(limit);

      if (error) {
        console.error('Error fetching match history:', error);
        return [];
      }

      return data || [];
    } catch (error) {
      console.error('Error fetching match history:', error);
      return [];
    }
  }

  /**
   * Get leaderboard
   */
  async getLeaderboard(limit: number = 10): Promise<any[]> {
    try {
      const { data, error } = await supabase
        .from('profiles')
        .select('username, games_played, games_won, total_territory_painted')
        .gt('games_played', 0)
        .order('games_won', { ascending: false })
        .order('games_played', { ascending: true })
        .limit(limit);

      if (error) {
        console.error('Error fetching leaderboard:', error);
        return [];
      }

      return (data || []).map((player, index) => ({
        rank: index + 1,
        username: player.username,
        gamesWon: player.games_won,
        gamesPlayed: player.games_played,
        winRate: player.games_played > 0 ? Math.round((player.games_won / player.games_played) * 100) : 0,
        totalTerritoryPainted: player.total_territory_painted,
      }));
    } catch (error) {
      console.error('Error fetching leaderboard:', error);
      return [];
    }
  }

  /**
   * Reset password
   */
  async resetPassword(email: string): Promise<{ success: boolean; error: string | null }> {
    try {
      const { error } = await supabase.auth.resetPasswordForEmail(email, {
        redirectTo: `${window.location.origin}/reset-password`,
      });

      if (error) {
        return { success: false, error: error.message };
      }

      return { success: true, error: null };
    } catch (error: any) {
      return { success: false, error: error.message || 'Failed to send reset email' };
    }
  }

  /**
   * Update password
   */
  async updatePassword(newPassword: string): Promise<{ success: boolean; error: string | null }> {
    try {
      const { error } = await supabase.auth.updateUser({
        password: newPassword,
      });

      if (error) {
        return { success: false, error: error.message };
      }

      return { success: true, error: null };
    } catch (error: any) {
      return { success: false, error: error.message || 'Failed to update password' };
    }
  }
}

// Export service instance
export const authService = new AuthService();