import { supabase } from './supabase';
import { GameRoom, Game, GameState, Position, GameSettings, RoomSettings } from '../types';
import { gameUtils } from '../game/gameLogic';

/**
 * Service for managing game rooms
 */
export class GameRoomService {
  /**
   * Create a new game room
   */
  async createRoom(
    creatorId: string,
    settings: RoomSettings
  ): Promise<{ room: GameRoom; error: null } | { room: null; error: string }> {
    try {
      const roomCode = gameUtils.generateRoomCode();
      
      const { data, error } = await supabase
        .from('game_rooms')
        .insert({
          room_code: roomCode,
          creator_id: creatorId,
          status: 'waiting',
          max_players: 2,
          current_players: 1,
          settings: settings,
        })
        .select()
        .maybeSingle();

      if (error) {
        console.error('Error creating room:', error);
        return { room: null, error: 'Failed to create room' };
      }

      return { room: data as GameRoom, error: null };
    } catch (error) {
      console.error('Error creating room:', error);
      return { room: null, error: 'Failed to create room' };
    }
  }

  /**
   * Join an existing game room
   */
  async joinRoom(
    roomCode: string,
    playerId: string
  ): Promise<{ room: GameRoom; error: null } | { room: null; error: string }> {
    try {
      // First, find the room by code
      const { data: room, error: findError } = await supabase
        .from('game_rooms')
        .select('*')
        .eq('room_code', roomCode)
        .eq('status', 'waiting')
        .maybeSingle();

      if (findError || !room) {
        return { room: null, error: 'Room not found or no longer available' };
      }

      if (room.current_players >= room.max_players) {
        return { room: null, error: 'Room is full' };
      }

      if (room.creator_id === playerId) {
        return { room: room as GameRoom, error: null };
      }

      // Update room to add player
      const { data: updatedRoom, error: updateError } = await supabase
        .from('game_rooms')
        .update({
          current_players: room.current_players + 1,
          status: room.current_players + 1 >= room.max_players ? 'active' : 'waiting',
        })
        .eq('id', room.id)
        .select()
        .maybeSingle();

      if (updateError) {
        return { room: null, error: 'Failed to join room' };
      }

      return { room: updatedRoom as GameRoom, error: null };
    } catch (error) {
      console.error('Error joining room:', error);
      return { room: null, error: 'Failed to join room' };
    }
  }

  /**
   * Leave a game room
   */
  async leaveRoom(
    roomId: string,
    playerId: string
  ): Promise<{ success: boolean; error: string | null }> {
    try {
      const { data: room, error: findError } = await supabase
        .from('game_rooms')
        .select('*')
        .eq('id', roomId)
        .maybeSingle();

      if (findError || !room) {
        return { success: false, error: 'Room not found' };
      }

      if (room.creator_id === playerId) {
        // If creator leaves, delete the room
        const { error: deleteError } = await supabase
          .from('game_rooms')
          .delete()
          .eq('id', roomId);

        if (deleteError) {
          return { success: false, error: 'Failed to delete room' };
        }
      } else {
        // If regular player leaves, decrease count
        const { error: updateError } = await supabase
          .from('game_rooms')
          .update({
            current_players: Math.max(1, room.current_players - 1),
            status: 'waiting',
          })
          .eq('id', roomId);

        if (updateError) {
          return { success: false, error: 'Failed to leave room' };
        }
      }

      return { success: true, error: null };
    } catch (error) {
      console.error('Error leaving room:', error);
      return { success: false, error: 'Failed to leave room' };
    }
  }

  /**
   * Get room details by ID
   */
  async getRoom(roomId: string): Promise<GameRoom | null> {
    try {
      const { data, error } = await supabase
        .from('game_rooms')
        .select('*')
        .eq('id', roomId)
        .maybeSingle();

      if (error) {
        console.error('Error fetching room:', error);
        return null;
      }

      return data as GameRoom;
    } catch (error) {
      console.error('Error fetching room:', error);
      return null;
    }
  }

  /**
   * Get available public rooms
   */
  async getAvailableRooms(): Promise<GameRoom[]> {
    try {
      const { data, error } = await supabase
        .from('game_rooms')
        .select('*')
        .eq('status', 'waiting')
        .lt('current_players', 'max_players')
        .order('created_at', { ascending: false })
        .limit(20);

      if (error) {
        console.error('Error fetching available rooms:', error);
        return [];
      }

      return (data as GameRoom[]).filter(room => !room.settings?.isPrivate);
    } catch (error) {
      console.error('Error fetching available rooms:', error);
      return [];
    }
  }
}

/**
 * Service for managing game sessions
 */
export class GameService {
  /**
   * Create a new game session
   */
  async createGame(
    roomId: string,
    player1Id: string,
    player2Id: string,
    gameSettings: GameSettings
  ): Promise<{ game: Game; error: null } | { game: null; error: string }> {
    try {
      const { data, error } = await supabase
        .from('games')
        .insert({
          room_id: roomId,
          player1_id: player1Id,
          player2_id: player2Id,
          status: 'active',
          current_round: 1,
          max_rounds: gameSettings.maxRounds,
          player1_score: 0,
          player2_score: 0,
          game_settings: gameSettings,
          started_at: new Date().toISOString(),
        })
        .select()
        .maybeSingle();

      if (error) {
        console.error('Error creating game:', error);
        return { game: null, error: 'Failed to create game' };
      }

      // Create initial game state
      await this.createInitialGameState(data.id, gameSettings);

      return { game: data as Game, error: null };
    } catch (error) {
      console.error('Error creating game:', error);
      return { game: null, error: 'Failed to create game' };
    }
  }

  /**
   * Create initial game state for a new round
   */
  private async createInitialGameState(
    gameId: string,
    gameSettings: GameSettings
  ): Promise<void> {
    try {
      const { error } = await supabase
        .from('game_states')
        .insert({
          game_id: gameId,
          round_number: 1,
          player1_position: { x: 2, y: 2 },
          player2_position: { x: gameSettings.gridSize - 3, y: gameSettings.gridSize - 3 },
          territory_data: {},
          round_time_remaining: gameSettings.roundDuration,
          round_status: 'active',
          player1_territory_count: 0,
          player2_territory_count: 0,
        });

      if (error) {
        console.error('Error creating initial game state:', error);
      }
    } catch (error) {
      console.error('Error creating initial game state:', error);
    }
  }

  /**
   * Update player position and territory
   */
  async updatePlayerPosition(
    gameId: string,
    playerId: string,
    newPosition: Position,
    territoryData: Record<string, string>,
    territoryCounts: { player1: number; player2: number }
  ): Promise<{ success: boolean; error: string | null }> {
    try {
      // Get current game state
      const { data: gameState, error: fetchError } = await supabase
        .from('game_states')
        .select('*')
        .eq('game_id', gameId)
        .order('round_number', { ascending: false })
        .limit(1)
        .maybeSingle();

      if (fetchError || !gameState) {
        return { success: false, error: 'Game state not found' };
      }

      // Determine which player moved
      const updateData: any = {
        territory_data: territoryData,
        player1_territory_count: territoryCounts.player1,
        player2_territory_count: territoryCounts.player2,
        last_updated: new Date().toISOString(),
      };

      // Get game to determine player roles
      const { data: game } = await supabase
        .from('games')
        .select('player1_id, player2_id')
        .eq('id', gameId)
        .maybeSingle();

      if (game) {
        if (playerId === game.player1_id) {
          updateData.player1_position = newPosition;
        } else if (playerId === game.player2_id) {
          updateData.player2_position = newPosition;
        }
      }

      const { error: updateError } = await supabase
        .from('game_states')
        .update(updateData)
        .eq('id', gameState.id);

      if (updateError) {
        console.error('Error updating game state:', updateError);
        return { success: false, error: 'Failed to update game state' };
      }

      return { success: true, error: null };
    } catch (error) {
      console.error('Error updating player position:', error);
      return { success: false, error: 'Failed to update player position' };
    }
  }

  /**
   * Get current game state
   */
  async getGameState(gameId: string): Promise<GameState | null> {
    try {
      const { data, error } = await supabase
        .from('game_states')
        .select('*')
        .eq('game_id', gameId)
        .order('round_number', { ascending: false })
        .limit(1)
        .maybeSingle();

      if (error) {
        console.error('Error fetching game state:', error);
        return null;
      }

      return data as GameState;
    } catch (error) {
      console.error('Error fetching game state:', error);
      return null;
    }
  }

  /**
   * End current round and update scores
   */
  async endRound(
    gameId: string,
    roundWinnerId: string | null,
    finalCounts: { player1: number; player2: number }
  ): Promise<{ success: boolean; error: string | null }> {
    try {
      // Get current game
      const { data: game, error: gameError } = await supabase
        .from('games')
        .select('*')
        .eq('id', gameId)
        .maybeSingle();

      if (gameError || !game) {
        return { success: false, error: 'Game not found' };
      }

      // Update scores
      let newPlayer1Score = game.player1_score;
      let newPlayer2Score = game.player2_score;
      
      if (roundWinnerId === game.player1_id) {
        newPlayer1Score += 1;
      } else if (roundWinnerId === game.player2_id) {
        newPlayer2Score += 1;
      }

      const currentRound = game.current_round;
      const isGameFinished = currentRound >= game.max_rounds;
      let gameWinnerId = null;

      if (isGameFinished) {
        if (newPlayer1Score > newPlayer2Score) {
          gameWinnerId = game.player1_id;
        } else if (newPlayer2Score > newPlayer1Score) {
          gameWinnerId = game.player2_id;
        }
      }

      // Update game
      const { error: updateGameError } = await supabase
        .from('games')
        .update({
          player1_score: newPlayer1Score,
          player2_score: newPlayer2Score,
          current_round: currentRound + 1,
          status: isGameFinished ? 'finished' : 'active',
          winner_id: gameWinnerId,
          ended_at: isGameFinished ? new Date().toISOString() : null,
        })
        .eq('id', gameId);

      if (updateGameError) {
        return { success: false, error: 'Failed to update game' };
      }

      // Update current round status
      const { error: updateStateError } = await supabase
        .from('game_states')
        .update({
          round_status: 'finished',
          player1_territory_count: finalCounts.player1,
          player2_territory_count: finalCounts.player2,
        })
        .eq('game_id', gameId)
        .eq('round_number', currentRound);

      if (updateStateError) {
        console.error('Error updating round state:', updateStateError);
      }

      // If game continues, create next round state
      if (!isGameFinished) {
        await this.createNewRoundState(gameId, currentRound + 1, game.game_settings);
      } else {
        // Game finished, record match history
        await this.recordMatchHistory(game, newPlayer1Score, newPlayer2Score, gameWinnerId);
      }

      return { success: true, error: null };
    } catch (error) {
      console.error('Error ending round:', error);
      return { success: false, error: 'Failed to end round' };
    }
  }

  /**
   * Create new round state
   */
  private async createNewRoundState(
    gameId: string,
    roundNumber: number,
    gameSettings: GameSettings
  ): Promise<void> {
    try {
      const { error } = await supabase
        .from('game_states')
        .insert({
          game_id: gameId,
          round_number: roundNumber,
          player1_position: { x: 2, y: 2 },
          player2_position: { x: gameSettings.gridSize - 3, y: gameSettings.gridSize - 3 },
          territory_data: {},
          round_time_remaining: gameSettings.roundDuration,
          round_status: 'active',
          player1_territory_count: 0,
          player2_territory_count: 0,
        });

      if (error) {
        console.error('Error creating new round state:', error);
      }
    } catch (error) {
      console.error('Error creating new round state:', error);
    }
  }

  /**
   * Record match history for both players
   */
  private async recordMatchHistory(
    game: Game,
    player1Score: number,
    player2Score: number,
    winnerId: string | null
  ): Promise<void> {
    try {
      const matchHistoryRecords = [
        {
          game_id: game.id,
          player_id: game.player1_id,
          opponent_id: game.player2_id!,
          result: winnerId === game.player1_id ? 'win' : (winnerId === game.player2_id ? 'loss' : 'draw'),
          final_score: player1Score,
          opponent_score: player2Score,
          rounds_won: player1Score,
          duration_seconds: Math.floor(
            (Date.now() - new Date(game.started_at!).getTime()) / 1000
          ),
        },
        {
          game_id: game.id,
          player_id: game.player2_id!,
          opponent_id: game.player1_id,
          result: winnerId === game.player2_id ? 'win' : (winnerId === game.player1_id ? 'loss' : 'draw'),
          final_score: player2Score,
          opponent_score: player1Score,
          rounds_won: player2Score,
          duration_seconds: Math.floor(
            (Date.now() - new Date(game.started_at!).getTime()) / 1000
          ),
        },
      ];

      const { error } = await supabase
        .from('match_history')
        .insert(matchHistoryRecords);

      if (error) {
        console.error('Error recording match history:', error);
      }

      // Update player stats
      await this.updatePlayerStats(game.player1_id, winnerId === game.player1_id);
      await this.updatePlayerStats(game.player2_id!, winnerId === game.player2_id);
    } catch (error) {
      console.error('Error recording match history:', error);
    }
  }

  /**
   * Update player statistics
   */
  private async updatePlayerStats(playerId: string, won: boolean): Promise<void> {
    try {
      const { data: profile, error: fetchError } = await supabase
        .from('profiles')
        .select('games_played, games_won')
        .eq('id', playerId)
        .maybeSingle();

      if (fetchError || !profile) {
        console.error('Error fetching player profile:', fetchError);
        return;
      }

      const { error: updateError } = await supabase
        .from('profiles')
        .update({
          games_played: profile.games_played + 1,
          games_won: profile.games_won + (won ? 1 : 0),
        })
        .eq('id', playerId);

      if (updateError) {
        console.error('Error updating player stats:', updateError);
      }
    } catch (error) {
      console.error('Error updating player stats:', error);
    }
  }
}

// Export service instances
export const gameRoomService = new GameRoomService();
export const gameService = new GameService();