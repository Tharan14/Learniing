import React, { useState, useEffect } from 'react';
import { Toaster } from 'react-hot-toast';
import { AuthProvider, useAuth } from './hooks/useAuth';
import { AuthWrapper } from './components/Auth/AuthWrapper';
import { HomePage } from './pages/HomePage';
import { GameLobby } from './pages/GameLobby';
import { GamePage } from './pages/GamePage';
import { CreateRoomModal } from './components/Room/CreateRoomModal';
import { RoomWaitingPage } from './pages/RoomWaitingPage';
import { LeaderboardPage } from './pages/LeaderboardPage';
import { useGameRoom } from './hooks/useGameRoom';
import { motion, AnimatePresence } from 'framer-motion';

// App pages enum
enum AppPage {
  AUTH = 'auth',
  HOME = 'home',
  LOBBY = 'lobby',
  GAME = 'game',
  ROOM_WAITING = 'room_waiting',
  LEADERBOARD = 'leaderboard',
}

function AppContent() {
  const { user, loading } = useAuth();
  const { currentRoom, createRoom, joinRoom, leaveRoom } = useGameRoom();
  
  const [currentPage, setCurrentPage] = useState<AppPage>(AppPage.AUTH);
  const [currentGameId, setCurrentGameId] = useState<string | null>(null);
  const [showCreateRoomModal, setShowCreateRoomModal] = useState(false);
  
  // Update page based on auth state
  useEffect(() => {
    if (!loading) {
      if (user) {
        if (currentRoom) {
          setCurrentPage(AppPage.ROOM_WAITING);
        } else if (currentPage === AppPage.AUTH) {
          setCurrentPage(AppPage.HOME);
        }
      } else {
        setCurrentPage(AppPage.AUTH);
        setCurrentGameId(null);
      }
    }
  }, [user, loading, currentRoom, currentPage]);
  
  // Navigation handlers
  const handleStartGame = () => {
    setCurrentPage(AppPage.LOBBY);
  };
  
  const handleCreateRoom = () => {
    setShowCreateRoomModal(true);
  };
  
  const handleCreateRoomSubmit = async (settings: any) => {
    const result = await createRoom(settings);
    setShowCreateRoomModal(false);
    
    if (result.success) {
      setCurrentPage(AppPage.ROOM_WAITING);
    }
  };
  
  const handleJoinRoom = async (roomId: string) => {
    setCurrentPage(AppPage.ROOM_WAITING);
  };
  
  const handleQuickPlay = async () => {
    // Find first available room and join it
    // For now, just go to lobby
    setCurrentPage(AppPage.LOBBY);
  };
  
  const handleStartGameFromRoom = (gameId: string) => {
    setCurrentGameId(gameId);
    setCurrentPage(AppPage.GAME);
  };
  
  const handleLeaveRoom = async () => {
    await leaveRoom();
    setCurrentPage(AppPage.LOBBY);
  };
  
  const handleLeaveGame = () => {
    setCurrentGameId(null);
    setCurrentPage(AppPage.HOME);
  };
  
  const handleGameEnd = () => {
    setCurrentGameId(null);
    setCurrentPage(AppPage.LOBBY);
  };
  
  const handleViewLeaderboard = () => {
    setCurrentPage(AppPage.LEADERBOARD);
  };
  
  const handleGoHome = () => {
    setCurrentPage(AppPage.HOME);
  };
  
  const handleAuthSuccess = () => {
    setCurrentPage(AppPage.HOME);
  };
  
  const handleLogout = async () => {
    // Handle logout in auth context
    setCurrentPage(AppPage.AUTH);
  };
  
  // Loading state
  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-gray-900 via-blue-900 to-purple-900 flex items-center justify-center">
        <motion.div
          className="text-center"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
        >
          <div className="w-16 h-16 border-4 border-blue-500 border-t-transparent rounded-full animate-spin mx-auto mb-4" />
          <h2 className="text-xl font-semibold text-white mb-2">Loading...</h2>
          <p className="text-gray-400">Preparing your gaming experience</p>
        </motion.div>
      </div>
    );
  }
  
  return (
    <div className="min-h-screen">
      <AnimatePresence mode="wait">
        {currentPage === AppPage.AUTH && (
          <motion.div
            key="auth"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.3 }}
          >
            <AuthWrapper onAuthSuccess={handleAuthSuccess} />
          </motion.div>
        )}
        
        {currentPage === AppPage.HOME && (
          <motion.div
            key="home"
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: 20 }}
            transition={{ duration: 0.3 }}
          >
            <HomePage
              onStartGame={handleStartGame}
              onViewLeaderboard={handleViewLeaderboard}
              onLogout={handleLogout}
            />
          </motion.div>
        )}
        
        {currentPage === AppPage.LOBBY && (
          <motion.div
            key="lobby"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            transition={{ duration: 0.3 }}
            className="min-h-screen bg-gradient-to-br from-gray-900 via-blue-900 to-purple-900 p-4"
          >
            <div className="max-w-6xl mx-auto py-8">
              <GameLobby
                onCreateRoom={handleCreateRoom}
                onJoinRoom={handleJoinRoom}
                onQuickPlay={handleQuickPlay}
              />
            </div>
          </motion.div>
        )}
        
        {currentPage === AppPage.ROOM_WAITING && currentRoom && (
          <motion.div
            key="room-waiting"
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 1.05 }}
            transition={{ duration: 0.3 }}
          >
            <RoomWaitingPage
              room={currentRoom}
              onStartGame={handleStartGameFromRoom}
              onLeaveRoom={handleLeaveRoom}
              onGoBack={handleGoHome}
            />
          </motion.div>
        )}
        
        {currentPage === AppPage.GAME && currentGameId && (
          <motion.div
            key="game"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.3 }}
          >
            <GamePage
              gameId={currentGameId}
              onLeaveGame={handleLeaveGame}
              onGameEnd={handleGameEnd}
            />
          </motion.div>
        )}
        
        {currentPage === AppPage.LEADERBOARD && (
          <motion.div
            key="leaderboard"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            transition={{ duration: 0.3 }}
          >
            <LeaderboardPage onGoBack={handleGoHome} />
          </motion.div>
        )}
      </AnimatePresence>
      
      {/* Create Room Modal */}
      <CreateRoomModal
        isOpen={showCreateRoomModal}
        onClose={() => setShowCreateRoomModal(false)}
        onSubmit={handleCreateRoomSubmit}
      />
      
      {/* Toast Notifications */}
      <Toaster
        position="top-right"
        toastOptions={{
          duration: 4000,
          style: {
            background: '#1f2937',
            color: '#f3f4f6',
            border: '1px solid #374151',
          },
          success: {
            iconTheme: {
              primary: '#10b981',
              secondary: '#f3f4f6',
            },
          },
          error: {
            iconTheme: {
              primary: '#ef4444',
              secondary: '#f3f4f6',
            },
          },
        }}
      />
    </div>
  );
}

function App() {
  return (
    <AuthProvider>
      <AppContent />
    </AuthProvider>
  );
}

export default App;