# Trail Painter Duel

**A Real-Time Multiplayer Territory Control Game**

Trail Painter Duel is an engaging web-based game where two players compete in real-time to paint and control territory on a grid-based arena. Built with modern web technologies, it demonstrates advanced full-stack development skills including real-time multiplayer capabilities, responsive design, and professional UI/UX.

![Trail Painter Duel Demo](docs/images/game-preview.png)

## Table of Contents

- [Features](#features)
- [Game Mechanics](#game-mechanics)
- [Technology Stack](#technology-stack)
- [Quick Start](#quick-start)
- [Deployment](#deployment)
- [Game Design](#game-design)
- [API Reference](#api-reference)
- [Contributing](#contributing)
- [License](#license)

## Features

### Core Gameplay
- **Real-Time Multiplayer**: Two players compete simultaneously on a shared grid
- **Territory Painting**: Move around the grid to paint cells and claim territory
- **Territory Conquest**: Steal opponent's painted areas by moving over them
- **Round-Based Matches**: 2-minute rounds, best of 3 wins the match
- **Live Statistics**: Real-time territory percentage and score tracking

### User Experience
- **Modern Gaming UI**: Clean, vibrant interface with smooth animations
- **Responsive Design**: Optimized for desktop and mobile devices
- **Touch Controls**: Mobile-friendly swipe controls for smartphone players
- **Professional Dashboard**: Game statistics, match history, and leaderboards
- **Real-Time Updates**: Instant position and territory synchronization

### Technical Highlights
- **Authentication System**: Secure user registration and login
- **Game Room Management**: Create private/public rooms with custom settings
- **Lobby System**: Join existing games or create new rooms
- **Leaderboard**: Global rankings based on wins and performance
- **Match History**: Track your games and improvement over time

## Game Mechanics

### Objective
Control the most territory when the round timer expires to win the round. Win the majority of rounds to win the match.

### Controls
- **Desktop**: WASD keys or Arrow keys for movement
- **Mobile**: Swipe gestures in any direction
- **Movement**: Players move one cell at a time on the grid
- **Painting**: Moving into a cell automatically paints it with your color

### Victory Conditions
1. **Round Victory**: Have the highest territory percentage when time expires
2. **Match Victory**: Win the majority of rounds (e.g., 2 out of 3)
3. **Territory Calculation**: Painted cells are counted as percentages of the total grid

### Game Flow
1. **Authentication**: Sign up or log in to your account
2. **Lobby**: Create a room or join an existing game
3. **Room Setup**: Wait for players and configure game settings
4. **Match Start**: Compete in multiple rounds
5. **Results**: View match results and statistics
6. **Rematch**: Play again or return to lobby

## Technology Stack

### Frontend
- **React 18.3** - Modern UI library with hooks and concurrent features
- **TypeScript** - Type-safe development and better code quality
- **Vite 6.0** - Fast build tool and development server
- **Tailwind CSS** - Utility-first CSS framework for styling
- **Framer Motion** - Smooth animations and transitions
- **React Hot Toast** - User-friendly notification system

### Backend & Database
- **Supabase** - Backend-as-a-Service with real-time capabilities
  - PostgreSQL database with real-time subscriptions
  - Authentication and user management
  - Row Level Security (RLS) for data protection
  - Real-time updates for multiplayer synchronization

### Development Tools
- **ESLint** - Code quality and consistency
- **pnpm** - Fast, disk space efficient package manager
- **Path Aliases** - Clean import statements with @/ prefix

### Deployment
- **Vercel/Netlify** - Frontend hosting with automatic deployments
- **Supabase Cloud** - Managed backend infrastructure
- **Custom Domain** - Professional URL for portfolio presentation

## Quick Start

### Prerequisites
- Node.js 18+ installed
- pnpm package manager
- Supabase account (free tier available)

### Installation

1. **Clone the repository**
   ```bash
   git clone https://github.com/yourusername/trail-painter-duel.git
   cd trail-painter-duel
   ```

2. **Install dependencies**
   ```bash
   pnpm install
   ```

3. **Set up environment variables**
   ```bash
   cp .env.example .env.local
   ```
   
   Fill in your Supabase credentials:
   ```env
   VITE_SUPABASE_URL=your_supabase_project_url
   VITE_SUPABASE_ANON_KEY=your_supabase_anon_key
   ```

4. **Set up the database**
   - Run the SQL scripts in `database/schema.sql`
   - Configure Row Level Security policies
   - See [DEPLOYMENT.md](docs/DEPLOYMENT.md) for detailed instructions

5. **Start development server**
   ```bash
   pnpm dev
   ```

6. **Open your browser**
   Navigate to `http://localhost:5173`

## Deployment

For complete deployment instructions including:
- Supabase project setup
- Database schema creation
- Environment configuration
- Frontend deployment to Vercel/Netlify
- Custom domain setup

See our comprehensive [DEPLOYMENT.md](docs/DEPLOYMENT.md) guide.

## Project Structure

```
trail-painter-duel/
├── src/
│   ├── components/          # React components
│   │   ├── Game/           # Game-specific components
│   │   ├── UI/             # Reusable UI components
│   │   ├── Auth/           # Authentication components
│   │   └── Room/           # Room management components
│   ├── hooks/              # Custom React hooks
│   ├── services/           # API and Supabase integration
│   ├── game/               # Game logic and state management
│   ├── types/              # TypeScript type definitions
│   ├── utils/              # Helper functions
│   └── pages/              # Main application pages
├── public/                 # Static assets
├── docs/                   # Documentation
├── database/               # SQL scripts and schema
└── deployment/             # Deployment configurations
```

## Game Design

For detailed information about game mechanics, design decisions, and technical architecture, see [GAME_DESIGN.md](docs/GAME_DESIGN.md).

## API Reference

Complete API documentation including database schema, real-time subscriptions, and service methods can be found in [API_REFERENCE.md](docs/API_REFERENCE.md).

## Performance

- **Real-time Updates**: Sub-100ms latency for player movements
- **Optimized Rendering**: Efficient grid updates with minimal re-renders
- **Mobile Performance**: 60fps animations on modern mobile devices
- **Bundle Size**: Optimized build under 1MB gzipped

## Browser Support

- Chrome 90+
- Firefox 88+
- Safari 14+
- Edge 90+
- Mobile browsers (iOS Safari, Chrome Mobile)

## Contributing

This project is designed as a portfolio piece, but contributions are welcome!

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

### Development Guidelines

- Follow TypeScript best practices
- Write meaningful commit messages
- Ensure all tests pass
- Update documentation for new features
- Use conventional commit format

## Troubleshooting

Common issues and solutions can be found in [TROUBLESHOOTING.md](docs/TROUBLESHOOTING.md).

## License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## Acknowledgments

- **Inspiration**: Classic territory control games and modern .io games
- **Design**: Modern gaming UI/UX patterns and best practices
- **Community**: React, Supabase, and web development communities

## Contact

For questions, suggestions, or collaboration opportunities:

- **Portfolio**: [Your Portfolio URL]
- **LinkedIn**: [Your LinkedIn Profile]
- **Email**: [Your Email]
- **GitHub**: [Your GitHub Profile]

---

**Built with ❤️ for the gaming community and modern web development**

*Trail Painter Duel - Where strategy meets speed in real-time territory battles!*